export const homeData =export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b3export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=30export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-152562export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350bexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://imagesexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flagexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-15export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b35export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=cropexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-154562export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6bexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=40export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e82696239export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?wexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://imagesexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  idexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-15456export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=80export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-152818130export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-150752542export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=80export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '1export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350bexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fitexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国1export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'httpsexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-15281813048export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=40export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 336export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=4export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSizeexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&hexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      imageexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-14998568export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350bexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fitexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: trueexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      locationexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photoexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-20830export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fitexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'httpsexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-15281813048export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=40export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photoexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://imagesexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location:export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-15export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b35export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=cropexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplashexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0bexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=5export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData =export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350bexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fitexport const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', 'export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '202export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车export const homeData = {
  destinations: [
    { name: '泰国', flag: '🇹🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '新加坡', flag: '🇸🇬', image: 'https://images.unsplash.com/photo-1525625293866-78f680976809?w=400&h=300&fit=crop' },
    { name: '越南', flag: '🇻🇳', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '柬埔寨', flag: '🇰🇭', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '缅甸', flag: '🇲🇲', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
    { name: '马来西亚', flag: '🇲🇾', image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop' },
  ],
  recommendations: [
    {
      title: '【陪你看世界·曼谷芭提雅6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=400&h=300&fit=crop',
      tags: ['绿山动物园', '萨美山岛出海', '大象村咖啡'],
      location: '曼谷 芭提雅'
    },
    {
      title: '【亲子臻选·新加坡+圣淘沙6日',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=300&fit=crop',
      tags: ['国家博物馆', '滨海湾花园', '国立大学'],
      location: '新加坡 圣淘沙'
    },
    {
      title: '【醉美越南·胡志明+芽庄7日',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1501281668745-2e8269623993-2e826?w=400&h=300&fit=crop',
      tags: ['美托', '统一宫', '西贡河游船'],
      location: '胡志明市 芽庄'
    },
    {
      title: '【穿越时空·探索柬埔寨7日之旅',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      tags: ['吴哥博物馆', '大小吴哥', '古墓丽影取景地'],
      location: '暹粒 金边'
    }
  ]
}

export const advisorData = {
  name: '6人游泰国部',
  id: '1000019',
  avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
  description: '高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。',
  itineraries: [
    {
      title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1545628731816-6b1816?w=800&h=500&fit=crop',
      tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海',
      location: '泰国'
    },
    {
      title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=500&fit=crop',
      tags: ['大皇宫', '水门寺', '丹嫩沙朵水上市场', '真理寺'],
      location: '泰国'
    },
    {
      title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
      days: '6天',
      image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&h=500&fit=crop',
      tags: ['尼莫海豚馆', '大象保护营', '蜜月岛'],
      location: '泰国'
    }
  ]
}

export const luxuryData = {
  regions: ['欧洲', '大洋洲', '东南亚', '中东非', '亚洲其他', '美洲', '南北极', '海岛', '中国'],
  durations: ['7天以下', '8-14天', '15-21天', '22天以上'],
  months: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
  tours: [
    {
      title: '（特惠）恋恋不舍·毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+蓝湾浮潜+船游鹿岛',
      days: '7天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 14900,
      date: '06月05日',
      groupSize: '9人小团',
      location: '毛里求斯'
    },
    {
      title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典·马丘比丘·复活节岛·纳斯卡线条',
      days: '25天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 129800,
      date: '06月06日',
      groupSize: '14人小团',
      location: '巴西/阿根廷/乌拉圭...'
    },
    {
      title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表演+雷吉斯坦广场',
      days: '17天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 33600,
      date: '06月08日',
      groupSize: '8人小团',
      location: '哈萨克斯坦/吉尔吉斯...'
    },
    {
      title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 36500,
      date: '06月08日',
      groupSize: '20人小团',
      location: '意大利/马耳他'
    },
    {
      title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+温泉SPA+布拉迪斯拉发',
      days: '14天',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=300&fit=crop',
      price: 28500,
      date: '06月10日',
      groupSize: '20人小团',
      location: '波兰/捷克/奥地利...'
    }
  ]
}

export const discoveryData = {
  posts: [
    {
      user: '6人游定制旅行',
      location: '意大利',
      image: 'https://images.unsplash.com/photo-1499856871958-5b9627545da8?w=400&h=500&fit=crop',
      content: '刚从维也纳回来！小众文艺就选奥地利+意大利',
      likes: 35
    },
    {
      user: '6人游海岛部',
      location: '印度尼西亚',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '寒假带4+岁娃去巴厘岛！0操心,爹妈也巨嗨',
      likes: 35,
      hasAdvisor: true
    },
    {
      user: '6人游定制旅行',
      location: '马尔代夫',
      image: 'https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=400&h=500&fit=crop',
      content: '值哭😭翡翠法鲁富士岛才是马代天花板！',
      likes: 16
    },
    {
      user: '6人游定制旅行',
      location: '土耳其',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '第一次去土耳其，酱玩钱省一半，浪漫不减分',
      likes: 11,
      hasAdvisor: true
    },
    {
      user: 'Club Med',
      location: '桂林',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '国庆倒计时⏰Club Med最后一波折扣来袭🎉',
      likes: 32
    },
    {
      user: '欧洲美学酒店100',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '穿越时光✨布达佩斯巴黎庭院酒店',
      likes: 12,
      hasAdvisor: true
    },
    {
      user: '6人游日韩部',
      location: '匈牙利',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '挖到一座超适合漫游的宝藏城市——布达佩斯',
      likes: 37
    },
    {
      user: '邮轮旅行',
      location: '沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...',
      image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=400&h=500&fit=crop',
      content: '',
      likes: 21,
      hasAdvisor: true
    }
  ]
}

export const itineraryData = {
  title: '芬兰追光，100%住玻璃屋！就问你冲不冲',
  image: 'https://images.unsplash.com/photo-1528181304800-0b350b350b35?w=800&h=400&fit=crop',
  tags: ['极光之旅', '精选行程', '亲子旅行', '自然风光', '北欧'],
  days: 8,
  date: '2026-2026年',
  content: `NASA认证：错过这次，下次就不知道要等多久了。
在全球所有极光的目的地中，极光概率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。
光是圣诞老人的罗瓦涅米，无缘极光活动多，只要是领头羊，就有98%的概率看见极光舞动的奇幻星空。
好消息是，6人游的爆款追光小团重磅返场啦！🎉🎉🎉
【芬兰追光8日，仅售6人！】
【体验佳罗瓦涅米，98%看北极光
✅圣诞老人村官方认证追光体验
✅100%入住玻璃屋，享TRCP极光体验合影
✅乘坐驯鹿拉雪橇穿越冰雪世界，亲手驯鹿雪橇
✅雪地黄泉冰上垂钓，体验破冰船+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+北极圈哈士奇雪橇
✅体验雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托
✅体验雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车+冰上垂钓+雪地摩托+雪地卡丁车