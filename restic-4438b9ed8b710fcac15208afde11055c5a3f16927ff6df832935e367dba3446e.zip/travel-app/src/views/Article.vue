<template>
  <div class="article-page">
    <!-- 顶部导航 -->
    <div class="page-header">
      <div class="header-actions">
        <button class="back-btn">‹</button>
        <div class="logo">🌴 6人游定制旅行</div>
        <div class="empty"></div>
      </div>
    </div>

    <!-- 文章内容 -->
    <div class="article-content">
      <!-- 头部大图 -->
      <div class="hero-img" style="background: linear-gradient(180deg, #2193b0, #6dd5ed);">
        <div class="hero-overlay">
          <h1 class="hero-title">芬兰追光</h1>
          <h2 class="hero-subtitle">8天</h2>
          <div class="hero-badge">跟团不一样</div>
        </div>
        <div class="hero-features">
          <div class="feature-item">
            <span class="check">✓</span>
            3晚圣诞-圣诞老人的故乡
          </div>
          <div class="feature-item">
            <span class="check">✓</span>
            99%大曝光-直视北极极光
          </div>
          <div class="feature-item">
            <span class="check">✓</span>
            100%保障-住极光玻璃屋
          </div>
        </div>
      </div>

      <!-- 作者信息 -->
      <div class="author-section">
        <div class="author-info">
          <div class="author-avatar"></div>
          <div class="author-details">
            <div class="author-name">6人游欧洲部</div>
            <div class="author-location">📍芬兰</div>
          </div>
        </div>
        <button class="follow-btn">+ 关注</button>
      </div>

      <!-- 文章标题和标签 -->
      <div class="article-header">
        <h1 class="article-title">芬兰追光，100%住玻璃屋❗就问你冲不冲</h1>
        <div class="article-tags">
          <span class="tag">#极光之旅</span>
          <span class="tag">#情侣蜜月</span>
          <span class="tag">#亲子旅行</span>
          <span class="tag">#自然风景</span>
        </div>
      </div>

      <!-- 文章正文 -->
      <div class="article-body">
        <div class="article-section">
          <p>NASA认证：2025-2026年是11年难得一遇的极高潮期。错过这次，下次就不知道要等多久了。</p>
        </div>

        <div class="article-section">
          <p>在全球所有极光的目的地中，追光机率大、体验舒适、玩法丰富的地方，芬兰当属第一梯队。</p>
        </div>

        <div class="article-section">
          <p>极光虽望老丈人罗瓦涅米来看，无数极光舞动的奇幻星空，就有98%的概率见北极光梦幻，只是其中之一。</p>
        </div>

        <div class="article-section">
          <p class="section-title">好消息是，6人游的爆款追光小团重返返场</p>
          <p>【芬兰追光 8天】精选酒店仅8888人！<br>✓31/2026年2月17日/2026年2月26日/2026年1月31日/2026年1月6日，仅限6人‼️</p>
        </div>

        <div class="article-section">
          <p class="section-title">【体验大升级】</p>
          <p>✓3晚住罗瓦涅米，98%看北极极光<br>✓圣诞老人村官方认证追光体验<br>✓100%入住玻璃屋，享VIP极光光影合影<br>✓坐到雪橇穿越冰雪世界，亲手驯鹿雪橇<br>✓冰雪摩托托托破冰，乘破冰船浮于冰面<br>✓去两千平方公里的紫水矿场，探北极露岩晶体<br>✓体验DIY极地发光火车，一路向北穿北极圈</p>
        </div>

        <div class="article-section">
          <p class="section-title">打卡芬兰+挪威段极光名城</p>
          <p>✓罗瓦涅米 - 圣诞老人的故乡 多观北极光博物馆，对极光有更全面的认识</p>
        </div>

        <div class="article-section">
          <p>✓凯米·波罗的海重要港口 参观冰雪城堡和千奇百怪的冰雕艺术</p>
        </div>

        <div class="article-section">
          <p>✓赫尔辛基-芬兰首都 世界唯一建在岩石中的岩石教堂</p>
        </div>

        <div class="article-section">
          <p>✓希尔克内斯-挪威边境小城 参观凯米冰雪酒店，在玻璃穹顶的冰城咖啡馆内，享用一杯热饮，静待极光降临</p>
        </div>

        <div class="article-section">
          <p class="section-title">【北极特色美食】</p>
          <p>✓在玻璃酒店一边等极光，一边吃自助晚餐<br>✓品尝挪威帝王蟹，当季龙虾，享免费明信片<br>✓世界第二的芬兰早餐吃早餐</p>
        </div>

        <div class="article-section">
          <p class="section-title">【6人游定制小团和市面团有啥不同？】</p>
          <p class="highlight">✓市面团20人起，行程不自由，我们2-6人的小时间<br>
          ✓6人游轻奢团仅限6人，可以照顾每个人的专属体验<br>
          ✓自助游-专车专导<br>
          ✓不含购物+实景花销，很多体验不包含，不费心<br>
          ✓6人游轻奢团包含全部体验项目，不用看别人眼色<br>
          ✓6人游住普通酒店<br>
          ✓6人游住独家资源，100%特色玻璃屋，体验顶级极光，惊艳朋友圈</p>
          </p>
        </div>

        <div class="article-section">
          <p>11-3月是芬兰极光最佳观赏期，热门玻璃屋咨询早，定制团和小团都抓紧时间占位！</p>
        </div>

        <div class="article-date">编辑于 2026-05-23</div>
      </div>

      <!-- 服务说明 -->
      <div class="service-section">
        <div class="service-title">
          <div class="service-icon">✓</div>
          专注定制旅行12年 服务超30万客户
        </div>
        <div class="service-features">
          <div class="service-feature">
            <div class="feature-icon">🛡️</div>
            <div class="feature-text">
              <div class="feature-title">私密旅行</div>
            </div>
          </div>
          <div class="service-feature">
            <div class="feature-icon">✨</div>
            <div class="feature-text">
              <div class="feature-title">量身定制</div>
            </div>
          </div>
          <div class="service-feature">
            <div class="feature-icon">🛡️</div>
            <div class="feature-text">
              <div class="feature-title">全程保障</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 相关推荐 -->
      <div class="recommend-section">
        <div class="recommend-title">大家还喜欢</div>
        <div class="recommend-grid">
          <div class="recommend-card">
            <div class="card-img" style="background: linear-gradient(180deg, #a8edea, #fed6e3);">
              <div class="location">📍冰岛</div>
            </div>
            <div class="card-content">
              <h4>专车专导+蓝湖温泉！带老爸老妈这么玩才是天花板！</h4>
            </div>
          </div>
          <div class="recommend-card">
            <div class="card-img" style="background: linear-gradient(180deg, #ffecd2, #fcb69f);">
              <div class="location">📍四川</div>
            </div>
            <div class="card-content">
              <h4>四姑娘山+雪山酒店！川西定制游的爽，谁懂!?</h4>
            </div>
          </div>
        </div>
      </div>

      <!-- 底部占位 -->
      <div class="bottom-space"></div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import TabBar from '../components/TabBar.vue'
</script>

<style scoped>
.article-page {
  min-height: 100vh;
  background: #ffffff;
  padding-bottom: 80px;
}

.page-header {
  position: sticky;
  top: 0;
  background: #ffffff;
  z-index: 100;
  padding: 12px 16px;
  border-bottom: 1px solid #f0f0f0;
}

.header-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.back-btn {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  width: 36px;
  height: 36px;
  border-radius: 2px;
  font-size: 22px;
  color: #333;
  cursor: pointer;
}

.logo {
  font-size: 15px;
  font-weight: 600;
  color: #333;
}

.empty {
  width: 36px;
}

.article-content {
  padding-bottom: 20px;
}

.hero-img {
  height: 360px;
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 16px;
}

.hero-overlay {
  text-align: center;
  color: #ffffff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.hero-title {
  font-size: 36px;
  font-weight: 700;
  margin: 0 0 6px 0;
}

.hero-subtitle {
  font-size: 20px;
  font-weight: 600;
  margin: 0 0 12px 0;
}

.hero-badge {
  display: inline-block;
  background: rgba(0,0,0,0.6);
  color: #ffffff;
  padding: 4px 16px;
  border-radius: 2px;
  font-size: 13px;
  font-weight: 600;
}

.hero-features {
  background: rgba(255,255,255,0.95);
  border-radius: 2px;
  padding: 12px;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  color: #333;
  margin-bottom: 6px;
}

.feature-item:last-child {
  margin-bottom: 0;
}

.check {
  color: #34C759;
  font-weight: 700;
}

.author-section {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  border-bottom: 1px solid #f0f0f0;
}

.author-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.author-avatar {
  width: 44px;
  height: 44px;
  border-radius: 2px;
  background: linear-gradient(135deg, #ffecd2, #fcb69f);
}

.author-name {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 2px;
  color: #333;
}

.author-location {
  font-size: 12px;
  color: #999;
}

.follow-btn {
  background: #34C759;
  color: #ffffff;
  border: none;
  padding: 6px 14px;
  border-radius: 2px;
  font-size: 12px;
  font-weight: 600;
  cursor: pointer;
}

.article-header {
  padding: 16px;
}

.article-title {
  font-size: 20px;
  font-weight: 700;
  line-height: 1.4;
  margin: 0 0 12px 0;
  color: #333;
}

.article-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.article-tags .tag {
  background: #f5f5f5;
  color: #666;
  padding: 4px 10px;
  border-radius: 2px;
  font-size: 12px;
  border: 1px solid #e0e0e0;
}

.article-body {
  padding: 0 16px;
}

.article-section {
  margin-bottom: 20px;
}

.article-section p {
  font-size: 14px;
  line-height: 1.8;
  color: #333;
  margin: 0;
}

.section-title {
  font-weight: 700;
  margin-bottom: 8px;
}

.highlight {
  background: #fff3e0;
  padding: 12px;
  border-radius: 2px;
  line-height: 2;
}

.article-date {
  font-size: 12px;
  color: #999;
  padding: 12px 0;
  border-top: 1px solid #f0f0f0;
}

.service-section {
  background: #f8f9fa;
  margin: 24px 16px;
  border-radius: 2px;
  padding: 20px 16px;
  border: 1px solid #e0e0e0;
}

.service-title {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 16px;
  justify-content: center;
  color: #333;
}

.service-icon {
  width: 20px;
  height: 20px;
  background: #34C759;
  color: #ffffff;
  border-radius: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}

.service-features {
  display: flex;
  justify-content: space-around;
}

.service-feature {
  text-align: center;
}

.feature-icon {
  width: 40px;
  height: 40px;
  background: #34C759;
  border-radius: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  margin: 0 auto 10px auto;
}

.feature-title {
  font-size: 13px;
  font-weight: 600;
  color: #333;
}

.recommend-section {
  padding: 16px;
  background: #f8f9fa;
}

.recommend-title {
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 12px;
  color: #333;
}

.recommend-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
}

.recommend-card {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.recommend-card .card-img {
  height: 140px;
  display: flex;
  align-items: flex-end;
  padding: 10px;
}

.recommend-card .location {
  color: #ffffff;
  font-size: 11px;
  font-weight: 600;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.recommend-card .card-content {
  padding: 10px;
}

.recommend-card h4 {
  font-size: 12px;
  font-weight: 600;
  line-height: 1.4;
  margin: 0;
  color: #333;
}

.bottom-space {
  height: 20px;
}
</style>
