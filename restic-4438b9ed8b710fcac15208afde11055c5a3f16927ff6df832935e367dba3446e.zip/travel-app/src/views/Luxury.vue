<template>
  <div class="luxury-page">
    <!-- 顶部渐变标题区 -->
    <div class="luxury-header">
      <div class="header-actions-top">
        <button class="mini-btn">···</button>
        <button class="mini-btn">⭕</button>
      </div>

      <div class="luxury-title">
        <div class="logo-icon">
          <svg viewBox="0 0 200 80" fill="none">
            <text x="100" y="45" text-anchor="middle" font-size="36" font-weight="700" fill="#5d4037">轻奢小团</text>
            <text x="100" y="65" text-anchor="middle" font-size="10" letter-spacing="8" fill="#8d6e63">LIGHT LUXURY</text>
          </svg>
        </div>
      </div>

      <div class="feature-row">
        <div class="feature-item">
          <span class="icon">💎</span>
          <span>品质纯玩</span>
        </div>
        <div class="feature-item">
          <span class="icon">🏨</span>
          <span>特色酒店</span>
        </div>
        <div class="feature-item">
          <span class="icon">🤵</span>
          <span>专业陪同</span>
        </div>
      </div>
    </div>

    <!-- 标签筛选区 -->
    <div class="filter-section">
      <div class="tag-row">
        <span class="tag active">欧洲</span>
        <span class="tag">大洋洲</span>
        <span class="tag">东南亚</span>
        <span class="tag">中东非</span>
      </div>
      <div class="tag-row">
        <span class="tag">亚洲其他</span>
        <span class="tag">美洲</span>
        <span class="tag">南北极</span>
        <span class="tag">海岛</span>
      </div>
      <div class="tag-row">
        <span class="tag">中国</span>
        <span class="tag-more" @click="showFilter = !showFilter">更多 ↓</span>
      </div>
    </div>

    <!-- 筛选弹窗 -->
    <div v-if="showFilter" class="filter-modal" @click="showFilter = false">
      <div class="filter-content" @click.stop>
        <div class="filter-group">
          <div class="filter-title">行程天数</div>
          <div class="tag-row">
            <span class="tag">7天以下</span>
            <span class="tag">8-14天</span>
            <span class="tag">15-21天</span>
            <span class="tag">22天以上</span>
          </div>
        </div>
        <div class="filter-group">
          <div class="filter-title">出行时间</div>
          <div class="tag-row">
            <span class="tag">1月</span>
            <span class="tag">2月</span>
            <span class="tag disabled">3月</span>
            <span class="tag disabled">4月</span>
            <span class="tag">5月</span>
            <span class="tag">6月</span>
          </div>
          <div class="tag-row">
            <span class="tag">7月</span>
            <span class="tag">8月</span>
            <span class="tag">9月</span>
            <span class="tag">10月</span>
            <span class="tag">11月</span>
            <span class="tag">12月</span>
          </div>
        </div>
        <div class="filter-actions">
          <button class="reset-btn">重置</button>
          <button class="confirm-btn">确定</button>
        </div>
      </div>
    </div>

    <!-- 行程列表 -->
    <div class="itinerary-list">
      <div v-for="(item, index) in itineraryList" :key="index" class="luxury-card">
        <div class="card-left">
          <div class="card-img" :style="{ background: item.bg }">
            <div class="days-tag">{{ item.days }}</div>
            <div class="location">{{ item.location }}</div>
          </div>
        </div>
        <div class="card-right">
          <div class="card-title">{{ item.title }}</div>
          <div class="card-meta">
            <span class="date-tag">{{ item.date }}</span>
            <span class="group-tag">{{ item.group }}</span>
          </div>
          <div class="card-desc">{{ item.desc }}</div>
          <div class="card-bottom">
            <div class="price-block">
              <span class="price-tag">特惠</span>
              <span class="price">¥{{ item.price }}</span>
              <span class="price-unit">/人</span>
            </div>
            <button class="chat-btn">💬 在线聊</button>
          </div>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import TabBar from '../components/TabBar.vue'

const showFilter = ref(false)

const itineraryList = ref([
  {
    bg: 'linear-gradient(180deg, #a8edea, #fed6e3)',
    days: '7天',
    location: '毛里求斯',
    title: '（特惠）恋恋不舍-毛里求斯6晚7天（追海豚观鲸+自然桥四驱车+...',
    date: '06月05日出发',
    group: '9人小团',
    desc: '探秘自然奇观与文化地标，如七色土、炮... 体验刺激海上活动，包括观鲸、追海豚及... 享受丰富户外探险，四驱车穿越自然桥至...',
    price: '14900'
  },
  {
    bg: 'linear-gradient(180deg, #667eea, #764ba2)',
    days: '25天',
    location: '巴西/阿根廷/乌拉...',
    title: '此生必去【穿越印加文化·南美五国文明探秘之旅】印加年度盛典...',
    date: '06月06日出发',
    group: '14人小团',
    desc: '亲历一年一度的印加太阳祭盛典，感受古... 览多元世界级奇观，一次探访马丘比丘+复... 享南美特色风情，野趣亚马逊雨林+布宜探...',
    price: '129800'
  },
  {
    bg: 'linear-gradient(180deg, #ffecd2, #fcb69f)',
    days: '17天',
    location: '哈萨克斯坦/吉尔吉...',
    title: '【传奇丝路·中亚5国16晚17日】地狱之门达瓦扎+希瓦古城+猎鹰表...',
    date: '06月08日出发',
    group: '8人小团',
    desc: '阿拉木图：体验草原文化王国，举目可见... 伊塞克湖区：汇集天山山脉流下的雪水，... 塔什干：置身突厥遗迹之中；撒马尔干：...',
    price: '33600'
  },
  {
    bg: 'linear-gradient(180deg, #4facfe, #00f2fe)',
    days: '14天',
    location: '意大利/马耳他',
    title: '【地中海春日盛景·南意+西西里+马耳他14日】欧洲“醉”美海岸...',
    date: '06月08日出发',
    group: '20人小团',
    desc: '从山间小镇到黄金海岸?开启南意柠檬传送门 总要去一趟“西西里的美丽传说”吧?✨ 绝美的地中海景色都藏在宝藏小国-马耳他',
    price: '36500'
  },
  {
    bg: 'linear-gradient(180deg, #f093fb, #f5576c)',
    days: '14天',
    location: '波兰/捷克/奥地利/...',
    title: '【纵横东欧PLUS·波捷奥斯匈5国14日】一价全含+入住城堡酒店+...',
    date: '06月10日出发',
    group: '20人小团',
    desc: '波兰最文艺城市弗罗茨瓦夫--寻找小矮人 品尝地道东欧美食，享受味蕾盛宴。 入住“布达佩斯大饭店”原型城堡酒店。',
    price: '28500'
  }
])
</script>

<style scoped>
.luxury-page {
  min-height: 100vh;
  background: white;
  padding-bottom: 80px;
}

.luxury-header {
  background: linear-gradient(180deg, #fff5d6, #ffffff);
  padding: 20px 20px 24px;
}

.header-actions-top {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-bottom: 20px;
}

.mini-btn {
  background: rgba(255,255,255,0.8);
  border: none;
  border-radius: 20px;
  padding: 8px 16px;
  font-size: 16px;
}

.luxury-title {
  text-align: center;
  margin-bottom: 16px;
}

.logo-icon {
  display: flex;
  justify-content: center;
}

.feature-row {
  display: flex;
  justify-content: center;
  gap: 28px;
}

.feature-item {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 16px;
  font-weight: 600;
  color: #5d4037;
}

.icon {
  font-size: 28px;
}

.filter-section {
  padding: 16px 20px;
}

.tag-row {
  display: flex;
  gap: 10px;
  margin-bottom: 10px;
  flex-wrap: wrap;
}

.tag {
  padding: 10px 24px;
  background: #f5f5f5;
  border-radius: 30px;
  font-size: 15px;
}

.tag.active {
  background: #fff3e0;
  color: #e65100;
}

.tag.disabled {
  color: #ccc;
}

.tag-more {
  padding: 10px 24px;
  background: #f5f5f5;
  border-radius: 30px;
  font-size: 15px;
  cursor: pointer;
}

.filter-modal {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: flex-end;
  z-index: 100;
}

.filter-content {
  background: white;
  width: 100%;
  border-radius: 20px 20px 0 0;
  padding: 24px 20px 30px;
  max-height: 80vh;
  overflow-y: auto;
}

.filter-group {
  margin-bottom: 24px;
}

.filter-title {
  font-size: 17px;
  font-weight: 600;
  margin-bottom: 16px;
}

.filter-actions {
  display: flex;
  gap: 16px;
  margin-top: 30px;
}

.reset-btn,
.confirm-btn {
  flex: 1;
  padding: 16px;
  border-radius: 30px;
  font-size: 16px;
  font-weight: 600;
  border: none;
}

.reset-btn {
  background: white;
  border: 2px solid #ddd;
}

.confirm-btn {
  background: #34C759;
  color: white;
}

.itinerary-list {
  padding: 0 20px;
}

.luxury-card {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #eee;
}

.card-left {
  width: 140px;
  flex-shrink: 0;
}

.card-img {
  width: 100%;
  height: 180px;
  border-radius: 12px;
  position: relative;
}

.days-tag {
  position: absolute;
  top: 8px;
  left: 8px;
  background: rgba(0,0,0,0.6);
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.location {
  position: absolute;
  bottom: 8px;
  left: 8px;
  color: white;
  font-size: 13px;
  text-shadow: 0 1px 3px rgba(0,0,0,0.5);
  display: flex;
  align-items: center;
  gap: 4px;
}

.card-right {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.card-title {
  font-size: 15px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 8px;
}

.card-meta {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
}

.date-tag {
  padding: 4px 8px;
  background: #fff3e0;
  color: #e65100;
  border-radius: 4px;
  font-size: 12px;
}

.group-tag {
  padding: 4px 8px;
  background: white;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 12px;
}

.card-desc {
  font-size: 13px;
  color: #999;
  line-height: 1.5;
  margin-bottom: 10px;
}

.card-bottom {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.price-block {
  display: flex;
  align-items: baseline;
  gap: 6px;
}

.price-tag {
  background: linear-gradient(135deg, #ff6b35, #f7931e);
  color: white;
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
}

.price {
  font-size: 28px;
  font-weight: 700;
  color: #333;
}

.price-unit {
  font-size: 13px;
  color: #666;
}

.chat-btn {
  background: #424242;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 30px;
  font-size: 14px;
}
</style>
