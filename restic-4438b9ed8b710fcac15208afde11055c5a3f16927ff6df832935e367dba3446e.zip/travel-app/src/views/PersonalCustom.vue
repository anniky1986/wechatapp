<template>
  <div class="personal-custom-page">
    <!-- 顶部导航 -->
    <div class="page-header">
      <div class="header-bg" style="background: linear-gradient(180deg, #a8edea, #fed6e3); height: 280px;">
        <div class="header-actions">
          <button class="back-btn">‹</button>
          <div class="empty"></div>
          <div class="action-buttons">
            <button class="action-btn">···</button>
            <button class="action-btn">⭕</button>
          </div>
        </div>
        <div class="hero-text">
          <div class="hero-title">定制旅游</div>
          <div class="hero-subtitle">就找6人游</div>
        </div>
      </div>
    </div>

    <!-- 主内容区 -->
    <div class="main-content">
      <!-- 标签切换 -->
      <div class="tabs-section">
        <div class="tabs">
          <div class="tab-item active">个人定制</div>
          <div class="tab-item">企业定制</div>
        </div>
      </div>

      <!-- 表单区域 -->
      <div class="form-card">
        <div class="form-title">专业旅行顾问 1V1量身设计行程</div>
        
        <div class="form-item">
          <div class="form-label">您想去的目的地</div>
          <div class="form-input-wrapper">
            <input type="text" placeholder="" class="form-input" />
            <div class="form-arrow">›</div>
          </div>
        </div>

        <div class="form-item">
          <div class="form-label">您的姓名</div>
          <div class="form-input-wrapper">
            <input type="text" placeholder="" class="form-input" />
          </div>
        </div>

        <div class="form-tags">
          <div class="tag">会议</div>
          <div class="tag active">考察</div>
          <div class="tag">团建</div>
          <div class="tag">其他</div>
        </div>

        <button class="submit-btn">提交需求</button>

        <div class="coupon-section">
          <div class="coupon-icon">🎫</div>
          <div class="coupon-text">您有 0 张优惠券，下单立减！</div>
        </div>

        <div class="contact-section">
          <div class="contact-title">我们会通过以下方式联系您，请您留意</div>
          <div class="contact-methods">
            <div class="method-item">
              <span class="method-icon">📞</span>
              <span class="method-text">电话 - 来电号码为 010-56149331 或 010-</span>
            </div>
            <div class="method-item">
              <span class="method-icon">💬</span>
              <span class="method-text">微信 - 📢 服务通知 里有旅行顾问的 好友申请</span>
            </div>
            <div class="method-item">
              <span class="method-icon">💬</span>
              <span class="method-text">短信 - 手机短信息</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 服务特色 -->
      <div class="features-section">
        <div class="feature-item">
          <div class="feature-icon">🛡️</div>
          <div class="feature-text">
            <div class="feature-title">私密旅行</div>
            <div class="feature-desc">只属于家人朋友的旅途时光</div>
          </div>
        </div>
        <div class="feature-item">
          <div class="feature-icon">👥</div>
          <div class="feature-text">
            <div class="feature-title">量身定制</div>
            <div class="feature-desc">旅行顾问一对一量身设计行程</div>
          </div>
        </div>
        <div class="feature-item">
          <div class="feature-icon">🛡️</div>
          <div class="feature-text">
            <div class="feature-title">全程保障</div>
            <div class="feature-desc">7x24小时全程跟踪服务及保障</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 浮动顾问 -->
    <div class="advisor-float">
      <div class="advisor-avatar"></div>
      <div class="advisor-info">
        <div class="advisor-status">在线咨询</div>
      </div>
      <div class="advisor-arrow">››</div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import TabBar from '../components/TabBar.vue'
</script>

<style scoped>
.personal-custom-page {
  min-height: 100vh;
  background: #ffffff;
  padding-bottom: 80px;
}

.page-header {
  position: relative;
}

.header-bg {
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
  padding: 16px;
}

.header-actions {
  position: absolute;
  top: 40px;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
}

.back-btn {
  background: rgba(255,255,255,0.9);
  border: none;
  width: 36px;
  height: 36px;
  border-radius: 2px;
  font-size: 24px;
  cursor: pointer;
}

.empty {
  width: 36px;
}

.action-buttons {
  display: flex;
  gap: 6px;
}

.action-btn {
  background: rgba(255,255,255,0.9);
  border: none;
  width: 36px;
  height: 36px;
  border-radius: 2px;
  font-size: 16px;
  cursor: pointer;
}

.hero-text {
  text-align: center;
  color: #34C759;
  margin-bottom: 16px;
}

.hero-title {
  font-size: 32px;
  font-weight: 700;
  margin-bottom: 4px;
}

.hero-subtitle {
  font-size: 24px;
  font-weight: 600;
}

.main-content {
  margin-top: -32px;
  position: relative;
  z-index: 1;
}

.tabs-section {
  background: rgba(255,255,255,0.95);
  border-radius: 2px 2px 0 0;
  padding: 16px 16px 0 16px;
}

.tabs {
  display: flex;
  gap: 16px;
}

.tab-item {
  flex: 1;
  text-align: center;
  padding: 10px 0;
  font-size: 16px;
  color: #999;
  font-weight: 500;
  position: relative;
}

.tab-item.active {
  color: #333;
  font-weight: 700;
}

.tab-item.active::after {
  content: '';
  position: absolute;
  bottom: 0;
  left: 50%;
  transform: translateX(-50%);
  width: 32px;
  height: 3px;
  background: #34C759;
  border-radius: 2px;
}

.form-card {
  background: #ffffff;
  padding: 20px 16px;
}

.form-title {
  text-align: center;
  font-size: 16px;
  color: #999;
  margin-bottom: 24px;
}

.form-item {
  margin-bottom: 20px;
}

.form-label {
  font-size: 18px;
  color: #999;
  margin-bottom: 6px;
}

.form-input-wrapper {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 0;
  border-bottom: 1px solid #eee;
}

.form-input {
  flex: 1;
  border: none;
  font-size: 18px;
  outline: none;
  background: transparent;
}

.form-arrow {
  font-size: 20px;
  color: #999;
}

.form-tags {
  display: flex;
  gap: 10px;
  margin-bottom: 24px;
}

.form-tags .tag {
  padding: 6px 14px;
  background: #f5f5f5;
  border-radius: 2px;
  font-size: 14px;
  color: #666;
}

.form-tags .tag.active {
  background: #34C759;
  color: #ffffff;
}

.submit-btn {
  width: 100%;
  background: #34C759;
  color: #ffffff;
  border: none;
  padding: 14px;
  border-radius: 2px;
  font-size: 18px;
  font-weight: 600;
  margin-bottom: 16px;
  cursor: pointer;
}

.coupon-section {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #fff3e0;
  padding: 12px;
  border-radius: 2px;
  margin-bottom: 20px;
}

.coupon-icon {
  font-size: 24px;
}

.coupon-text {
  flex: 1;
  font-size: 14px;
  color: #ff6b35;
  font-weight: 600;
}

.contact-section {
  background: #f8f9fa;
  padding: 16px;
  border-radius: 2px;
  border: 1px solid #e0e0e0;
}

.contact-title {
  font-size: 14px;
  color: #666;
  margin-bottom: 12px;
  text-align: center;
}

.contact-methods {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.method-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
}

.method-icon {
  font-size: 20px;
}

.method-text {
  flex: 1;
  font-size: 13px;
  color: #666;
  line-height: 1.6;
}

.features-section {
  display: flex;
  padding: 24px 16px;
  gap: 12px;
}

.features-section .feature-item {
  flex: 1;
  text-align: center;
  background: #f8f9fa;
  border-radius: 2px;
  padding: 16px 10px;
  border: 1px solid #e0e0e0;
}

.features-section .feature-icon {
  width: 52px;
  height: 52px;
  margin: 0 auto 10px auto;
  background: linear-gradient(135deg, #34C759, #a8edea);
  border-radius: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 26px;
}

.features-section .feature-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
  margin-bottom: 6px;
}

.features-section .feature-desc {
  font-size: 12px;
  color: #999;
  line-height: 1.5;
}

.advisor-float {
  position: fixed;
  right: 16px;
  bottom: 90px;
  display: flex;
  align-items: center;
  gap: 8px;
  background: linear-gradient(135deg, #34C759, #a8edea);
  padding: 10px 14px;
  border-radius: 2px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.15);
  z-index: 50;
}

.advisor-float .advisor-avatar {
  width: 40px;
  height: 40px;
  border-radius: 2px;
  background: linear-gradient(135deg, #ffecd2, #fcb69f);
}

.advisor-float .advisor-status {
  color: #ffffff;
  font-size: 14px;
  font-weight: 600;
}

.advisor-float .advisor-arrow {
  color: #ffffff;
  font-size: 20px;
}
</style>
