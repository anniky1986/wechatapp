<template>
  <div class="advisor-page">
    <!-- 顶部 -->
    <div class="page-header">
      <button class="back-btn">‹</button>
      <div class="header-title">目的地</div>
      <div class="header-actions">
        <button class="action-btn">···</button>
        <button class="action-btn">⭕</button>
      </div>
    </div>

    <!-- 1级分类顶部 -->
    <div class="level-one-tabs">
      <div 
        v-for="cat in levelOneCategories" 
        :key="cat.id"
        :class="['tab-item', { active: activeLevelOne === cat.id }]"
        @click="selectLevelOne(cat.id)"
      >
        {{ cat.name }}
      </div>
    </div>

    <!-- 分类侧边栏和内容区域 -->
    <div class="content-wrapper">
      <!-- 2级分类左侧 -->
      <div class="category-sidebar">
        <div 
          v-for="cat in levelTwoCategories" 
          :key="cat.id"
          :class="['category-item', { active: activeLevelTwo === cat.id }]"
          @click="selectLevelTwo(cat.id)"
        >
          {{ cat.name }}
        </div>
      </div>

      <!-- 3级区域和内容 -->
      <div class="main-content">
        <!-- 三级区域网格 -->
        <div class="level-three-grid">
          <div v-for="area in levelThreeAreas" :key="area.id" class="area-card">
            <div class="area-img" :style="{ background: area.bg }">
              <span>{{ area.name }}</span>
            </div>
          </div>
        </div>

        <div class="more-link">更多目的地 ›</div>

        <!-- 顾问推荐行程 -->
        <div class="section-title">顾问推荐行程</div>
        <div class="itinerary-list">
          <div v-for="item in recommendedItineraries" :key="item.id" class="itinerary-card">
            <div class="itinerary-img" :style="{ background: item.bg }">
              <div class="days-badge">{{ item.days }}</div>
            </div>
            <div class="itinerary-info">
              <div class="itinerary-title">{{ item.title }}</div>
              <div class="itinerary-desc">{{ item.desc }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import TabBar from '../components/TabBar.vue'

// Mock API 数据
const mockData = {
  levelOne: [
    { id: 1, name: '亚洲' },
    { id: 2, name: '欧洲' },
    { id: 3, name: '美洲' },
    { id: 4, name: '大洋洲' },
    { id: 5, name: '非洲' }
  ],
  levelTwo: [
    { id: 1, name: '东南亚', parent: 1 },
    { id: 2, name: '中东非', parent: 1 },
    { id: 3, name: '澳新', parent: 4 },
    { id: 4, name: '韩国', parent: 1 },
    { id: 5, name: '欧洲', parent: 2 },
    { id: 6, name: '北美洲', parent: 3 },
    { id: 7, name: '南美洲', parent: 3 },
    { id: 8, name: '南亚', parent: 1 },
    { id: 9, name: '海岛', parent: 1 },
    { id: 10, name: '免签', parent: 1 }
  ],
  levelThree: [
    { id: 1, name: '泰国', parent: 1, bg: 'linear-gradient(180deg, #ffecd2, #fcb69f)' },
    { id: 2, name: '新加坡', parent: 1, bg: 'linear-gradient(180deg, #a8edea, #fed6e3)' },
    { id: 3, name: '越南', parent: 1, bg: 'linear-gradient(180deg, #667eea, #764ba2)' },
    { id: 4, name: '柬埔寨', parent: 1, bg: 'linear-gradient(180deg, #f093fb, #f5576c)' },
    { id: 5, name: '缅甸', parent: 1, bg: 'linear-gradient(180deg, #4facfe, #00f2fe)' },
    { id: 6, name: '马来西亚', parent: 1, bg: 'linear-gradient(180deg, #43e97b, #38f9d7)' }
  ],
  itineraries: [
    { id: 1, title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村...', desc: '曼谷 芭提雅', days: '6天', bg: 'linear-gradient(180deg, #2193b0, #6dd5ed)', parent: 1 },
    { id: 2, title: '【亲子臻选·新加坡+圣淘沙6日】国家博物馆+滨海湾花园+国立大...', desc: '新加坡 圣淘沙', days: '6天', bg: 'linear-gradient(180deg, #ffecd2, #fcb69f)', parent: 1 },
    { id: 3, title: '【醉美越南·胡志明+芽庄7日】美托+统一宫+西贡河游船晚餐+珍...', desc: '胡志明市 芽庄', days: '7天', bg: 'linear-gradient(180deg, #667eea, #764ba2)', parent: 1 },
    { id: 4, title: '【穿越时空·探索柬埔寨7日之旅】吴哥博物馆+大小吴哥+《古墓丽...', desc: '暹粒 金边', days: '7天', bg: 'linear-gradient(180deg, #a8edea, #fed6e3)', parent: 1 }
  ]
}

const activeLevelOne = ref(1) // 默认选中亚洲
const activeLevelTwo = ref(1) // 默认选中东南亚

// 计算属性：根据选中的1级分类筛选2级分类
const levelOneCategories = computed(() => mockData.levelOne)

const levelTwoCategories = computed(() => {
  return mockData.levelTwo.filter(cat => cat.parent === activeLevelOne.value)
})

const levelThreeAreas = computed(() => {
  return mockData.levelThree.filter(area => area.parent === activeLevelTwo.value)
})

const recommendedItineraries = computed(() => {
  return mockData.itineraries.filter(item => item.parent === activeLevelTwo.value)
})

// 选择1级分类
const selectLevelOne = (id) => {
  activeLevelOne.value = id
  // 默认选中该1级分类下的第一个2级分类
  const firstLevelTwo = mockData.levelTwo.find(cat => cat.parent === id)
  if (firstLevelTwo) {
    activeLevelTwo.value = firstLevelTwo.id
  }
}

// 选择2级分类
const selectLevelTwo = (id) => {
  activeLevelTwo.value = id
}
</script>

<style scoped>
.advisor-page {
  min-height: 100vh;
  background: white;
  padding-bottom: 80px;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
}

.back-btn {
  font-size: 28px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
}

.header-title {
  font-size: 18px;
  font-weight: 600;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.action-btn {
  background: #f5f5f5;
  border: none;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  font-size: 16px;
  cursor: pointer;
}

.level-one-tabs {
  display: flex;
  gap: 8px;
  padding: 8px 16px;
  overflow-x: auto;
  background: #f8f9fa;
}

.tab-item {
  flex-shrink: 0;
  padding: 8px 20px;
  font-size: 14px;
  color: #666;
  border-radius: 20px;
  background: white;
}

.tab-item.active {
  background: #34C759;
  color: white;
  font-weight: 600;
}

.content-wrapper {
  display: flex;
  flex: 1;
}

.category-sidebar {
  width: 100px;
  background: #f8f9fa;
  flex-shrink: 0;
}

.category-item {
  padding: 14px 16px;
  font-size: 14px;
  color: #666;
  border-left: 3px solid transparent;
}

.category-item.active {
  background: white;
  border-left-color: #34C759;
  color: #34C759;
  font-weight: 600;
}

.main-content {
  flex: 1;
  padding: 16px;
  overflow-y: auto;
}

.level-three-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-bottom: 16px;
}

.area-card {
  border-radius: 12px;
  overflow: hidden;
}

.area-img {
  height: 100px;
  display: flex;
  align-items: flex-end;
  padding: 12px;
}

.area-img span {
  color: white;
  font-size: 20px;
  font-weight: 700;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.more-link {
  text-align: center;
  color: #34C759;
  font-size: 14px;
  margin-bottom: 24px;
}

.section-title {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 12px;
}

.itinerary-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.itinerary-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 12px rgba(0,0,0,0.08);
}

.itinerary-img {
  height: 180px;
  position: relative;
}

.days-badge {
  position: absolute;
  bottom: 10px;
  left: 10px;
  color: white;
  font-size: 36px;
  font-weight: 700;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.itinerary-info {
  padding: 12px;
}

.itinerary-title {
  font-size: 15px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 6px;
}

.itinerary-desc {
  font-size: 13px;
  color: #999;
}
</style>
