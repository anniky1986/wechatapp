<template>
  <div class="home-page">
    <!-- 顶部导航 -->
    <div class="page-header">
      <div class="header-left">
        <div class="logo">🌴 6人游</div>
      </div>
      <div class="search-box">
        <span class="search-text">搜索目的地</span>
        <span class="ai-search">AI搜索</span>
      </div>
      <div class="user-avatar">
        <div class="avatar-circle"></div>
      </div>
    </div>

    <!-- 轮播图 -->
    <div class="banner-section">
      <div class="banner-item">
        <div class="banner-img" style="background: linear-gradient(135deg, #a8edea, #fed6e3);">
          <div class="banner-title">土兰班牙</div>
        </div>
      </div>
    </div>

    <!-- 功能标签 -->
    <div class="feature-tabs">
      <div class="feature-item">
        <div class="feature-img" style="background: #e3f2fd;"></div>
        <div class="feature-name">查玩法</div>
        <div class="feature-desc">图文攻略</div>
      </div>
      <div class="feature-item active">
        <div class="feature-img" style="background: #f3e5f5;"></div>
        <div class="feature-name">问AI</div>
        <div class="feature-desc">规划行程</div>
      </div>
      <div class="feature-item">
        <div class="feature-img" style="background: #e8f5e9;"></div>
        <div class="feature-name">定制出行</div>
        <div class="feature-desc">家庭 企业</div>
      </div>
    </div>

    <!-- 滚动通知 -->
    <div class="notice-bar">
      <div class="notice-icon"></div>
      <div class="notice-text">共有708244人咨询定制行程</div>
      <div class="notice-arrow">›</div>
    </div>

    <!-- 金刚区 -->
    <div class="kingkong-section">
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #e3f2fd, #bbdefb);"></div>
        <div class="kingkong-name">出境</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #f3e5f5, #e1bee7);"></div>
        <div class="kingkong-name">国内</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #e8f5e9, #c8e6c9);"></div>
        <div class="kingkong-name">海岛</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #fff3e0, #ffe0b2);"></div>
        <div class="kingkong-name">邮轮</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #ffebee, #ffcdd2);"></div>
        <div class="kingkong-name">极地</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #f1f8e9, #dcedc8);"></div>
        <div class="kingkong-name">亲子</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #e0f7fa, #b2ebf2);"></div>
        <div class="kingkong-name">暑假</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #fce4ec, #f8bbd9);"></div>
        <div class="kingkong-name">父母</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #ede7f6, #d1c4e9);"></div>
        <div class="kingkong-name">团建</div>
      </div>
      <div class="kingkong-item">
        <div class="kingkong-img" style="background: linear-gradient(135deg, #fff8e1, #ffecb3);"></div>
        <div class="kingkong-name">小团</div>
      </div>
    </div>

    <!-- 内容区域 -->
    <div class="content-area">
      <!-- 左侧列 -->
      <div class="content-col">
        <!-- 热门推荐 -->
        <div class="section-header">
          <div class="section-title">热门推荐</div>
          <div class="section-more">更多 ›</div>
        </div>
        <div class="large-card">
          <div class="large-img" style="background: linear-gradient(180deg, #ffecd2, #fcb69f);"></div>
          <div class="large-tag">西班牙·葡萄牙</div>
          <div class="large-days">12日</div>
          <div class="large-title">西班牙葡萄牙12日经典之旅，高性价比游欧洲！</div>
        </div>

        <!-- 深度策划 -->
        <div class="section-header">
          <div class="section-title">深度策划</div>
          <div class="section-more">更多 ›</div>
        </div>

        <div class="article-card">
          <div class="article-img" style="background: linear-gradient(180deg, #4facfe, #00f2fe);"></div>
          <div class="article-tag">冬の亲子</div>
          <div class="article-location">北海道</div>
          <div class="article-days">8天7晚环球记</div>
          <div class="article-content">
            <div class="article-title">北海道の冬</div>
            <div class="article-desc">有一种回忆，叫北海道的雪</div>
            <div class="article-bottom">
              <div class="article-author">6人游定制旅行</div>
              <div class="article-likes">🤍 55</div>
            </div>
          </div>
        </div>

        <div class="article-card">
          <div class="article-img" style="background: linear-gradient(180deg, #43e97b, #38f9d7);"></div>
          <div class="article-tag">宁夏</div>
          <div class="article-days">6日</div>
          <div class="article-content">
            <div class="article-title">推窗大漠银河！跟我套玩宁夏6日，全家不吃苦</div>
            <div class="article-bottom">
              <div class="article-author">6人游国内部</div>
              <div class="article-likes">🤍 55</div>
            </div>
          </div>
        </div>

        <div class="article-card">
          <div class="article-img" style="background: linear-gradient(180deg, #f093fb, #f5576c);"></div>
          <div class="article-tag">童趣新加坡</div>
          <div class="article-days">6天5晚·圣淘沙岛</div>
          <div class="article-content">
            <div class="article-title">家有6岁以上娃👦就酱冲新加坡·爆省心</div>
            <div class="article-bottom">
              <div class="article-author">6人游定制旅行</div>
              <div class="article-likes">🤍 99+</div>
            </div>
          </div>
        </div>
      </div>

      <!-- 右列 -->
      <div class="content-col">
        <!-- 热门目的地 -->
        <div class="section-header">
          <div class="section-title">热门目的地</div>
          <div class="section-more">更多 ›</div>
        </div>
        <div class="dest-grid">
          <div class="dest-item">
            <div class="dest-img" style="background: linear-gradient(180deg, #a8edea, #fed6e3);"></div>
            <div class="dest-name">新加坡</div>
          </div>
          <div class="dest-item">
            <div class="dest-img" style="background: linear-gradient(180deg, #ff9a9e, #fecfef);"></div>
            <div class="dest-name">新西兰</div>
          </div>
          <div class="dest-item">
            <div class="dest-img" style="background: linear-gradient(180deg, #a18cd1, #fbc2eb);"></div>
            <div class="dest-name">肯尼亚</div>
          </div>
          <div class="dest-item">
            <div class="dest-img" style="background: linear-gradient(180deg, #667eea, #764ba2);"></div>
            <div class="dest-name">法国</div>
          </div>
          <div class="dest-item">
            <div class="dest-img" style="background: linear-gradient(180deg, #4facfe, #00f2fe);"></div>
            <div class="dest-name">加拿大</div>
          </div>
          <div class="dest-item">
            <div class="dest-img" style="background: linear-gradient(180deg, #43e97b, #38f9d7);"></div>
            <div class="dest-name">冰岛</div>
          </div>
        </div>

        <!-- 轻奢小团 -->
        <div class="luxury-card">
          <div class="luxury-img" style="background: linear-gradient(180deg, #a8edea, #fed6e3);"></div>
          <div class="luxury-tag">轻奢小团</div>
          <div class="luxury-title">8.1【悠闲锡兰-斯里兰卡6日】雅拉+本达拉双...</div>
          <div class="luxury-meta">
            <div class="luxury-date">06月05日出发</div>
            <div class="luxury-people">9人小团</div>
          </div>
          <div class="luxury-price">¥9980<span class="luxury-unit">/人</span>
          <div class="luxury-more">更多轻奢小团 ⏩</div>
        </div>

        <div class="article-card">
          <div class="article-img" style="background: linear-gradient(180deg, #ffecd2, #fcb69f);"></div>
          <div class="article-tag">新西兰南北岛</div>
          <div class="article-days">12日完整路线参考 (有3日小...</div>
          <div class="article-content">
            <div class="article-title">5-9月冲新西兰太划算，省30%！！美巨凉爽</div>
            <div class="article-bottom">
              <div class="article-author">🛩️ 新西兰</div>
              <div class="article-author">6人游定制旅行</div>
              <div class="article-likes">🤍 34</div>
            </div>
          </div>
        </div>

        <div class="article-card">
          <div class="article-img" style="background: linear-gradient(180deg, #667eea, #764ba2);"></div>
          <div class="article-tag">川西6日</div>
          <div class="article-days">全程不赶路+慢节奏</div>
          <div class="article-content">
            <div class="article-title">随停专车+雪山酒店川西定制游的爽，谁懂!?</div>
            <div class="article-bottom">
              <div class="article-author">🛩️ 成都</div>
              <div class="article-author">6人游国内部</div>
              <div class="article-likes">🤍 32</div>
            </div>
          </div>
        </div>

        <!-- 用户卡片 -->
        <div class="user-card">
          <div class="user-avatar">👨‍👩‍👧‍👦</div>
          <div class="user-name">亲子旅行</div>
          <div class="user-desc">在孩子最该旅行的年纪，不要错过带他/她一起去探索世界</div>
          <button class="follow-btn">关注</button>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import TabBar from '../components/TabBar.vue'
</script>

<style scoped>
.home-page {
  min-height: 100vh;
  background: #ffffff;
  padding-bottom: 80px;
}

.page-header {
  display: flex;
  align-items: center;
  padding: 12px 16px;
  background: #ffffff;
  border-bottom: 1px solid #f0f0f0;
}

.header-left {
  flex-shrink: 0;
}

.logo {
  font-size: 18px;
  font-weight: 700;
  color: #333;
}

.search-box {
  flex: 1;
  display: flex;
  align-items: center;
  background: #f5f5f5;
  border-radius: 2px;
  padding: 8px 12px;
  margin: 0 12px;
  justify-content: space-between;
}

.search-text {
  font-size: 14px;
  color: #999;
}

.ai-search {
  font-size: 12px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: #ffffff;
  padding: 4px 10px;
  border-radius: 2px;
}

.user-avatar {
  flex-shrink: 0;
}

.avatar-circle {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: linear-gradient(135deg, #a8edea, #fed6e3);
  border: 2px solid #34C759;
}

.banner-section {
  padding: 12px 16px;
}

.banner-item {
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}

.banner-img {
  height: 140px;
  display: flex;
  align-items: flex-end;
  padding: 16px;
}

.banner-title {
  font-size: 20px;
  font-weight: 700;
  color: #ffffff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.feature-tabs {
  display: flex;
  padding: 12px 16px;
  gap: 12px;
}

.feature-item {
  flex: 1;
  background: #ffffff;
  border-radius: 2px;
  padding: 12px 10px;
  text-align: center;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.feature-item.active {
  position: relative;
}

.feature-item.active::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, #ffd89b, #19547b);
}

.feature-img {
  width: 32px;
  height: 32px;
  border-radius: 2px;
  margin: 0 auto 6px auto;
}

.feature-name {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 2px;
  color: #333;
}

.feature-desc {
  font-size: 11px;
  color: #999;
}

.notice-bar {
  display: flex;
  align-items: center;
  padding: 10px 16px;
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.notice-icon {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: linear-gradient(135deg, #667eea, #764ba2);
  margin-right: 8px;
}

.notice-text {
  flex: 1;
  font-size: 13px;
  color: #666;
}

.notice-arrow {
  font-size: 18px;
  color: #999;
}

.kingkong-section {
  display: grid;
  grid-template-columns: repeat(5, 1fr);
  gap: 8px;
  padding: 0 16px 16px 16px;
}

.kingkong-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.kingkong-img {
  width: 40px;
  height: 40px;
  border-radius: 2px;
  margin-bottom: 4px;
}

.kingkong-name {
  font-size: 12px;
  color: #666;
}

.content-area {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
  padding: 0 16px 0 16px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.section-title {
  font-size: 15px;
  font-weight: 700;
  color: #333;
}

.section-more {
  font-size: 13px;
  color: #999;
}

.large-card {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
  margin-bottom: 12px;
}

.large-img {
  height: 140px;
  position: relative;
  padding: 10px;
  display: flex;
  justify-content: space-between;
  align-items: flex-end;
}

.large-tag {
  color: #ffffff;
  font-size: 12px;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.large-days {
  font-size: 22px;
  font-weight: 700;
  color: #ffffff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.large-title {
  padding: 10px;
  font-size: 13px;
  line-height: 1.5;
  color: #333;
}

.dest-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 8px;
  margin-bottom: 12px;
}

.dest-item {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.dest-img {
  height: 80px;
  display: flex;
  align-items: flex-end;
  padding: 8px;
}

.dest-name {
  padding: 8px;
  font-size: 13px;
  font-weight: 600;
  color: #ffffff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.luxury-card {
  background: #ffffff;
  border-radius: 2px;
  padding: 10px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
  margin-bottom: 12px;
}

.luxury-img {
  height: 90px;
  border-radius: 2px;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.luxury-tag {
  position: absolute;
  top: 8px;
  left: 8px;
  background: rgba(0,0,0,0.6);
  color: #ffffff;
  padding: 4px 10px;
  border-radius: 2px;
  font-size: 12px;
}

.luxury-title {
  font-size: 13px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 8px;
  color: #333;
}

.luxury-meta {
  display: flex;
  gap: 8px;
  margin-bottom: 8px;
}

.luxury-date {
  font-size: 11px;
  background: #fff3e0;
  color: #ff9800;
  padding: 3px 8px;
  border-radius: 2px;
}

.luxury-people {
  font-size: 11px;
  background: #f5f5f5;
  color: #666;
  padding: 3px 8px;
  border-radius: 2px;
}

.luxury-price {
  font-size: 20px;
  font-weight: 700;
  color: #ff6b35;
  margin-bottom: 8px;
}

.luxury-unit {
  font-size: 12px;
  color: #999;
  font-weight: 400;
}

.luxury-more {
  text-align: center;
  background: #f5f5f5;
  padding: 8px;
  border-radius: 2px;
  font-size: 13px;
  color: #666;
}

.article-card {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
  margin-bottom: 10px;
}

.article-img {
  height: 160px;
  position: relative;
  padding: 8px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.article-tag {
  position: absolute;
  top: 8px;
  left: 8px;
  background: rgba(0,0,0,0.6);
  color: #ffffff;
  padding: 3px 8px;
  border-radius: 2px;
  font-size: 11px;
}

.article-location {
  position: absolute;
  top: 8px;
  right: 8px;
  color: #ffffff;
  font-size: 15px;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.article-days {
  color: #ffffff;
  font-size: 12px;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.article-content {
  padding: 10px;
}

.article-title {
  font-size: 14px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 6px;
  color: #333;
}

.article-desc {
  font-size: 12px;
  color: #999;
  margin-bottom: 6px;
}

.article-bottom {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  color: #999;
}

.user-card {
  background: #ffffff;
  border-radius: 2px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
  text-align: center;
  margin-bottom: 10px;
}

.user-avatar {
  font-size: 40px;
  margin-bottom: 10px;
}

.user-name {
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 8px;
  color: #333;
}

.user-desc {
  font-size: 12px;
  color: #999;
  margin-bottom: 12px;
}

.follow-btn {
  background: #34C759;
  color: #ffffff;
  border: none;
  padding: 8px 32px;
  border-radius: 2px;
  font-size: 14px;
  font-weight: 600;
}
</style>