<template>
  <div class="discovery-page">
    <!-- 顶部标签 -->
    <div class="tab-header">
      <div class="tab-item">关注</div>
      <div class="tab-item active">精选</div>
      <div class="tab-actions">
        <button class="mini-action">···</button>
        <button class="mini-action">⭕</button>
      </div>
    </div>

    <!-- 搜索栏 -->
    <div class="search-row">
      <div class="search-input">
        <span class="search-placeholder">旅行灵感枯竭？点我唤醒</span>
      </div>
      <div class="ai-badge">AI搜索</div>
    </div>

    <!-- 瀑布流内容 -->
    <div class="discovery-grid">
      <!-- 左侧列 -->
      <div class="grid-col">
        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #a8edea, #fed6e3);">
            <div class="location-tag">📍 意大利</div>
          </div>
          <div class="note-content">
            <div class="note-title">刚从维也纳回来！小众文艺就选奥地利+意大利</div>
            <div class="note-footer">
              <span class="author">6人游定制旅行</span>
              <span class="likes">🤍 35</span>
            </div>
          </div>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #667eea, #764ba2);">
            <div class="location-tag">📍 马尔代夫</div>
            <div class="price-tag">18900</div>
          </div>
          <div class="note-content">
            <div class="note-title">值哭😭翡翠法鲁富士岛才是马代天花板！</div>
            <div class="note-footer">
              <span class="author">6人游定制旅行</span>
              <span class="likes">🤍 16</span>
            </div>
          </div>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #f093fb, #f5576c);">
            <div class="location-tag">📍 桂林</div>
            <div class="flash-tag">国庆假期福利 倒计时</div>
          </div>
          <div class="note-content">
            <div class="note-title">国庆倒计时⏰Club Med最后一波折扣来袭🎉</div>
            <div class="note-footer">
              <span class="author">Club Med</span>
              <span class="likes">🤍 32</span>
            </div>
          </div>
        </div>

        <div class="user-card">
          <div class="user-avatar">
            <div class="logo-icon">🌄</div>
          </div>
          <div class="user-name">6人游日韩部</div>
          <div class="user-desc">从千年古都到火山海岛，千年宫殿到萌趣乐园，日韩远比想象中好玩</div>
          <button class="follow-btn">关注</button>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #4facfe, #00f2fe);">
            <div class="location-tag">📍 匈牙利</div>
          </div>
          <div class="note-content">
            <div class="note-title">挖到一座超适合漫游的宝藏城市 —— 布达佩斯</div>
            <div class="note-footer">
              <span class="author">6人游定制旅行</span>
              <span class="likes">🤍 37</span>
            </div>
          </div>
        </div>
      </div>

      <!-- 右侧列 -->
      <div class="grid-col">
        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #ffecd2, #fcb69f);">
            <div class="location-tag">📍 印度尼西亚</div>
          </div>
          <div class="note-content">
            <div class="note-title">寒假带4+娃轻奢去巴厘岛！0操心，爹妈也巨嗨</div>
            <div class="note-footer">
              <span class="author">6人游海岛部</span>
              <span class="likes">🤍 35</span>
            </div>
          </div>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #43e97b, #38f9d7);">
            <div class="location-tag">📍 土耳其</div>
            <div class="consult-badge">
              <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50" class="consult-avatar" />
              <div>
                <div class="consult-name">顾问</div>
                <div class="consult-action">在线咨询 ››</div>
              </div>
            </div>
          </div>
          <div class="note-content">
            <div class="note-title">第一次去土耳其，酱玩钱省一半，浪漫不减分</div>
            <div class="note-footer">
              <span class="author">6人游欧洲部</span>
              <span class="likes">🤍 11</span>
            </div>
          </div>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #a18cd1, #fbc2eb);">
            <div class="location-tag">📍 匈牙利</div>
          </div>
          <div class="note-content">
            <div class="note-title">穿越时光 | 布达佩斯超赞酒店</div>
            <div class="note-footer">
              <span class="author">欧洲美奢酒店100</span>
              <span class="likes">🤍 12</span>
            </div>
          </div>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #ff9a9e, #fecfef);">
            <div class="location-tag">📍 纳米比亚</div>
          </div>
          <div class="note-content">
            <div class="note-title">年末自驾游：和家人在南澳邂逅野生动物🦒</div>
            <div class="note-footer">
              <span class="author">特澳之旅</span>
              <span class="likes">🤍 25</span>
            </div>
          </div>
        </div>

        <div class="note-card">
          <div class="note-img" style="background: linear-gradient(180deg, #2193b0, #6dd5ed);">
            <div class="location-tag">📍 邮轮</div>
            <div class="consult-badge">
              <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50" class="consult-avatar" />
              <div>
                <div class="consult-name">顾问</div>
                <div class="consult-action">在线咨询 ››</div>
              </div>
            </div>
          </div>
          <div class="note-content">
            <div class="note-title">沙漠与海的碰撞！MSC神女号带你解锁阿拉伯海黄金航线，10日穿越3国...</div>
            <div class="note-footer">
              <span class="author">邮轮旅行</span>
              <span class="likes">🤍 21</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import TabBar from '../components/TabBar.vue'
</script>

<style scoped>
.discovery-page {
  min-height: 100vh;
  background: white;
  padding-bottom: 80px;
}

.tab-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
}

.tab-item {
  font-size: 16px;
  color: #999;
  padding: 4px 8px;
}

.tab-item.active {
  color: #333;
  font-weight: 700;
  border-bottom: 2px solid #34C759;
}

.tab-actions {
  display: flex;
  gap: 12px;
}

.mini-action {
  background: #f5f5f5;
  border: none;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  font-size: 16px;
}

.search-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 0 20px 16px;
}

.search-input {
  flex: 1;
  background: #f5f7fa;
  border-radius: 24px;
  padding: 12px 16px;
  color: #999;
  font-size: 14px;
}

.ai-badge {
  background: linear-gradient(135deg, #667eea, #764ba2);
  padding: 6px 12px;
  border-radius: 16px;
  color: white;
  font-size: 12px;
  font-weight: 600;
}

.discovery-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  padding: 0 12px;
}

.grid-col {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.note-card {
  background: white;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 1px 6px rgba(0,0,0,0.06);
}

.note-img {
  height: 200px;
  position: relative;
}

.location-tag {
  position: absolute;
  bottom: 10px;
  left: 10px;
  background: rgba(0,0,0,0.6);
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
}

.price-tag {
  position: absolute;
  bottom: 10px;
  right: 10px;
  color: white;
  font-size: 18px;
  font-weight: 700;
  text-shadow: 0 1px 3px rgba(0,0,0,0.5);
}

.flash-tag {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0,0,0,0.7);
  color: white;
  padding: 8px 16px;
  border-radius: 8px;
  text-align: center;
  font-size: 14px;
}

.consult-badge {
  position: absolute;
  bottom: 10px;
  right: 10px;
  background: rgba(0,0,0,0.8);
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  border-radius: 24px;
  color: white;
}

.consult-avatar {
  width: 36px;
  height: 36px;
  border-radius: 50%;
}

.consult-name {
  font-size: 13px;
  font-weight: 600;
}

.consult-action {
  font-size: 12px;
  color: #34C759;
}

.note-content {
  padding: 12px;
}

.note-title {
  font-size: 14px;
  line-height: 1.4;
  margin-bottom: 10px;
}

.note-footer {
  display: flex;
  justify-content: space-between;
  font-size: 12px;
  color: #999;
}

.user-card {
  background: linear-gradient(180deg, #f1f8e9, #e8f5e9);
  border-radius: 12px;
  padding: 20px;
  text-align: center;
}

.user-avatar {
  margin: 0 auto 12px;
}

.logo-icon {
  width: 64px;
  height: 64px;
  border-radius: 16px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 32px;
}

.user-name {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 6px;
}

.user-desc {
  font-size: 13px;
  color: #666;
  line-height: 1.5;
  margin-bottom: 16px;
}

.follow-btn {
  background: #34C759;
  color: white;
  border: none;
  padding: 8px 32px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 600;
}
</style>
