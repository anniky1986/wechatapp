<template>
  <div class="custom-page">
    <!-- 顶部 -->
    <div class="page-header">
      <button class="back-btn">‹</button>
      <div class="header-title">定制旅游</div>
      <div class="header-actions">
        <button class="action-btn">···</button>
        <button class="action-btn">⭕</button>
      </div>
    </div>

    <!-- 内容区域 -->
    <div class="content">
      <!-- 引导区域 -->
      <div class="hero-section">
        <div class="hero-bg" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);">
          <h2>为您定制专属行程</h2>
          <p>专业顾问1对1服务，满足您的个性化需求</p>
        </div>
      </div>

      <!-- 快速预约表单 -->
      <div class="booking-form">
        <div class="form-section">
          <div class="section-title">基本信息</div>
          <div class="form-item">
            <label>出行时间</label>
            <input type="text" placeholder="请选择出行时间" />
          </div>
          <div class="form-item">
            <label>出行人数</label>
            <input type="text" placeholder="请输入出行人数" />
          </div>
          <div class="form-item">
            <label>目的地</label>
            <input type="text" placeholder="请输入目的地" />
          </div>
          <div class="form-item">
            <label>预算</label>
            <input type="text" placeholder="请输入预算范围" />
          </div>
        </div>

        <div class="form-section">
          <div class="section-title">联系信息</div>
          <div class="form-item">
            <label>姓名</label>
            <input type="text" placeholder="请输入姓名" />
          </div>
          <div class="form-item">
            <label>手机号</label>
            <input type="text" placeholder="请输入手机号" />
          </div>
          <div class="form-item">
            <label>备注</label>
            <textarea placeholder="请输入您的特殊需求或备注" rows="3"></textarea>
          </div>
        </div>

        <button class="submit-btn">提交需求</button>
      </div>

      <!-- 服务优势 -->
      <div class="advantages">
        <div class="section-title">我们的优势</div>
        <div class="advantage-list">
          <div class="advantage-item">
            <div class="icon">👨‍💼</div>
            <div class="text">
              <h3>专业顾问</h3>
              <p>1对1专属服务，量身定制</p>
            </div>
          </div>
          <div class="advantage-item">
            <div class="icon">📋</div>
            <div class="text">
              <h3>免费方案</h3>
              <p>免费提供2-3个行程方案</p>
            </div>
          </div>
          <div class="advantage-item">
            <div class="icon">⚡</div>
            <div class="text">
              <h3>快速响应</h3>
              <p>24小时内专人联系</p>
            </div>
          </div>
        </div>
      </div>

      <!-- 定制案例 -->
      <div class="cases">
        <div class="section-header">
          <h3>精彩案例</h3>
          <div class="more">更多 ›</div>
        </div>
        <div class="case-list">
          <div v-for="item in cases" :key="item.id" class="case-card">
            <div class="case-img" :style="{ background: item.bg }"></div>
            <div class="case-info">
              <h4>{{ item.title }}</h4>
              <p>{{ item.desc }}</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import TabBar from '../components/TabBar.vue'

const cases = ref([
  {
    id: 1,
    title: '北欧极光之旅',
    desc: '芬兰-瑞典-挪威12日深度体验',
    bg: 'linear-gradient(180deg, #2193b0, #6dd5ed)'
  },
  {
    id: 2,
    title: '日本关西风情',
    desc: '大阪-京都-奈良7日文化之旅',
    bg: 'linear-gradient(180deg, #ffecd2, #fcb69f)'
  },
  {
    id: 3,
    title: '新西兰南岛探险',
    desc: '皇后镇-基督城10日户外之旅',
    bg: 'linear-gradient(180deg, #667eea, #764ba2)'
  }
])
</script>

<style scoped>
.custom-page {
  min-height: 100vh;
  background: #f8f9fa;
  padding-bottom: 80px;
}

.page-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 16px 20px;
  background: white;
}

.back-btn {
  font-size: 28px;
  background: none;
  border: none;
  cursor: pointer;
  padding: 0;
}

.header-title {
  font-size: 18px;
  font-weight: 600;
}

.header-actions {
  display: flex;
  gap: 12px;
}

.action-btn {
  background: #f5f5f5;
  border: none;
  border-radius: 50%;
  width: 36px;
  height: 36px;
  font-size: 16px;
  cursor: pointer;
}

.content {
  padding: 0 16px 20px;
}

.hero-section {
  margin-bottom: 16px;
}

.hero-bg {
  padding: 40px 20px;
  border-radius: 16px;
  color: white;
  text-align: center;
}

.hero-bg h2 {
  font-size: 24px;
  font-weight: 700;
  margin-bottom: 8px;
}

.hero-bg p {
  font-size: 14px;
  opacity: 0.9;
}

.booking-form {
  background: white;
  border-radius: 16px;
  padding: 20px;
  margin-bottom: 16px;
}

.form-section {
  margin-bottom: 20px;
}

.section-title {
  font-size: 16px;
  font-weight: 600;
  margin-bottom: 16px;
}

.form-item {
  margin-bottom: 16px;
}

.form-item label {
  display: block;
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
}

.form-item input,
.form-item textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  font-size: 14px;
  box-sizing: border-box;
}

.submit-btn {
  width: 100%;
  padding: 14px;
  background: #34C759;
  color: white;
  border: none;
  border-radius: 24px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
}

.advantages {
  background: white;
  border-radius: 16px;
  padding: 20px;
  margin-bottom: 16px;
}

.advantage-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.advantage-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.advantage-item .icon {
  width: 48px;
  height: 48px;
  background: #f0f2f5;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.advantage-item h3 {
  font-size: 15px;
  font-weight: 600;
  margin-bottom: 4px;
}

.advantage-item p {
  font-size: 13px;
  color: #999;
}

.cases {
  background: white;
  border-radius: 16px;
  padding: 20px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.section-header h3 {
  font-size: 16px;
  font-weight: 600;
}

.more {
  font-size: 14px;
  color: #999;
}

.case-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.case-card {
  display: flex;
  gap: 12px;
  border-radius: 12px;
  overflow: hidden;
  background: #f8f9fa;
}

.case-img {
  width: 100px;
  height: 80px;
  flex-shrink: 0;
}

.case-info {
  padding: 12px;
  flex: 1;
}

.case-info h4 {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 4px;
}

.case-info p {
  font-size: 12px;
  color: #999;
}
</style>
