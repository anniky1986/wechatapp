<template>
  <div class="itinerary-page">
    <!-- 顶部图片 -->
    <div class="hero-img" style="background: linear-gradient(180deg, #667eea, #764ba2);">
      <div class="back-btn" @click="goBack">‹</div>
    </div>

    <!-- 标题区 -->
    <div class="title-section">
      <h1 class="main-title">芬兰追光8日 | 跟团不一样</h1>
      <div class="tags-row">
        <span class="tag">极光之旅</span>
        <span class="tag">亲子出行</span>
        <span class="tag">自然风光</span>
      </div>
    </div>

    <!-- 顾问条 -->
    <div class="advisor-bar">
      <div class="advisor-info">
        <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=50&h=50" class="adv-avatar" />
        <div>
          <div class="adv-name">6人游欧洲部</div>
          <div class="adv-desc">专注定制旅行12年 · 服务超50万客户</div>
        </div>
      </div>
      <button class="follow-btn">+ 关注</button>
    </div>

    <!-- 亮点 -->
    <div class="highlights">
      <div class="highlight-item">
        <span class="h-icon">⭐</span>
        <span class="h-text">NASA认证：错过这次下次就要等12年了！</span>
      </div>
      <div class="highlight-item">
        <span class="h-icon">🌌</span>
        <span class="h-text">在全球所有极光地中，芬兰是概率极高的极光王国之一</span>
      </div>
      <div class="highlight-item">
        <span class="h-icon">🎿</span>
        <span class="h-text">体验芬兰最酷的荒野玩法，骑着雪地摩托穿越北极圈</span>
      </div>
      <div class="highlight-item">
        <span class="h-icon">🏨</span>
        <span class="h-text">去芬兰玻璃屋睡一晚，躺平看极光</span>
      </div>
    </div>

    <!-- 特色标签 -->
    <div class="feature-labels">
      <div class="f-label">
        <span class="f-icon">🏕️</span>
        <span>特色酒店</span>
      </div>
      <div class="f-label">
        <span class="f-icon">💎</span>
        <span>全程纯玩</span>
      </div>
      <div class="f-label">
        <span class="f-icon">🤵</span>
        <span>专业陪同</span>
      </div>
    </div>

    <!-- 时间线 -->
    <div class="timeline-section">
      <div class="section-header">
        <h2>行程概览</h2>
        <div class="more-btn">收起 ↓</div>
      </div>

      <div class="timeline">
        <div class="day-item active">
          <div class="day-num">Day1</div>
          <div class="day-content">
            <div class="day-title">赫尔辛基集合</div>
            <div class="day-desc">抵达芬兰首都赫尔辛基，入住酒店休息，准备开始极光之旅</div>
          </div>
        </div>

        <div class="day-item">
          <div class="day-num">Day2</div>
          <div class="day-content">
            <div class="day-title">赫尔辛基 - 罗瓦涅米</div>
            <div class="day-desc">飞往北极圈，参观圣诞老人村，跨越北极圈线</div>
          </div>
        </div>

        <div class="day-item">
          <div class="day-num">Day3</div>
          <div class="day-content">
            <div class="day-title">罗瓦涅米 - 列维</div>
            <div class="day-desc">前往列维，驾驶雪地摩托深入北极森林，夜晚守候极光</div>
          </div>
        </div>

        <div class="day-item">
          <div class="day-num">Day4</div>
          <div class="day-content">
            <div class="day-title">列维玻璃屋</div>
            <div class="day-desc">入住著名玻璃屋度假村，在温暖屋内欣赏壮丽极光</div>
          </div>
        </div>

        <div class="day-item">
          <div class="day-num">Day5</div>
          <div class="day-content">
            <div class="day-title">列维 - 伊纳里</div>
            <div class="day-desc">前往伊纳里湖，乘坐驯鹿雪橇探索萨米文化</div>
          </div>
        </div>
      </div>
    </div>

    <!-- 底部固定条 -->
    <div class="bottom-bar">
      <div class="price-info">
        <div class="price-label">参考费用</div>
        <div class="price-val">¥ 68,000<span class="unit">/人起</span></div>
      </div>
      <button class="consult-btn">立即咨询</button>
    </div>

    <!-- 浮动顾问 -->
    <div class="float-advisor">
      <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=60&h=60" class="float-avatar" />
      <div class="float-content">
        <div class="float-name">顾问</div>
        <div class="float-action">在线咨询 ››</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()
const goBack = () => { router.back() }
</script>

<style scoped>
.itinerary-page {
  min-height: 100vh;
  background: white;
  padding-bottom: 100px;
  position: relative;
}

.hero-img {
  height: 280px;
  position: relative;
}

.back-btn {
  position: absolute;
  top: 20px;
  left: 20px;
  width: 40px;
  height: 40px;
  background: rgba(0,0,0,0.5);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-size: 24px;
}

.title-section {
  padding: 20px;
}

.main-title {
  font-size: 22px;
  font-weight: 700;
  margin: 0 0 12px;
}

.tags-row {
  display: flex;
  gap: 8px;
}

.tags-row .tag {
  padding: 4px 10px;
  background: #e8f5e9;
  color: #34C759;
  border-radius: 12px;
  font-size: 12px;
}

.advisor-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 20px;
  background: #f9f9f9;
  margin: 0 16px 16px;
  border-radius: 12px;
}

.advisor-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.adv-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
}

.adv-name {
  font-size: 14px;
  font-weight: 600;
}

.adv-desc {
  font-size: 12px;
  color: #999;
}

.follow-btn {
  border: 1px solid #ddd;
  background: white;
  padding: 6px 14px;
  border-radius: 16px;
  font-size: 13px;
  color: #34C759;
}

.highlights {
  padding: 0 20px 20px;
}

.highlight-item {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  margin-bottom: 10px;
  font-size: 14px;
  line-height: 1.5;
}

.h-icon {
  font-size: 18px;
  margin-top: 2px;
}

.h-text {
  flex: 1;
  color: #333;
}

.feature-labels {
  display: flex;
  justify-content: space-around;
  padding: 16px 20px;
  background: #f9f9f9;
  margin: 0 16px 20px;
  border-radius: 12px;
}

.f-label {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: #666;
}

.f-icon {
  font-size: 24px;
}

.timeline-section {
  padding: 0 20px;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.section-header h2 {
  font-size: 16px;
  font-weight: 700;
  margin: 0;
}

.more-btn {
  font-size: 13px;
  color: #34C759;
}

.timeline {
  padding-left: 10px;
}

.day-item {
  display: flex;
  gap: 16px;
  margin-bottom: 20px;
  padding-left: 14px;
  border-left: 2px solid #eee;
  position: relative;
}

.day-item::before {
  content: '';
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #ddd;
  position: absolute;
  left: -5px;
  top: 4px;
}

.day-item.active {
  border-left-color: #34C759;
}

.day-item.active::before {
  background: #34C759;
  width: 10px;
  height: 10px;
  left: -6px;
}

.day-num {
  font-size: 13px;
  font-weight: 700;
  color: #999;
  width: 44px;
  flex-shrink: 0;
}

.day-item.active .day-num {
  color: #34C759;
}

.day-title {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 4px;
}

.day-desc {
  font-size: 13px;
  color: #666;
  line-height: 1.5;
}

.bottom-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  max-width: 430px;
  margin: 0 auto;
  background: white;
  padding: 14px 20px;
  padding-bottom: calc(14px + env(safe-area-inset-bottom, 0));
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
}

.price-label {
  font-size: 12px;
  color: #999;
  margin-bottom: 4px;
}

.price-val {
  font-size: 24px;
  font-weight: 700;
  color: #ff6b35;
}

.unit {
  font-size: 13px;
  color: #999;
  font-weight: 400;
}

.consult-btn {
  background: linear-gradient(135deg, #34C759, #2E8B4F);
  color: white;
  border: none;
  padding: 12px 32px;
  border-radius: 24px;
  font-size: 15px;
  font-weight: 600;
}

.float-advisor {
  position: fixed;
  bottom: 100px;
  right: 20px;
  background: #222;
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 16px;
  border-radius: 30px;
  color: white;
}

.float-avatar {
  width: 44px;
  height: 44px;
  border-radius: 50%;
}

.float-name {
  font-size: 13px;
  font-weight: 600;
}

.float-action {
  font-size: 12px;
  color: #34C759;
}
</style>
