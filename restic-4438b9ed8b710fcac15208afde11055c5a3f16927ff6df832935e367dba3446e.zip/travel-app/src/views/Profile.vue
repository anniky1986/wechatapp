<template>
  <div class="profile-page">
    <!-- 顶部区域 -->
    <div class="profile-header">
      <div class="user-info">
        <div class="avatar"></div>
        <div class="user-details">
          <div class="phone">134****1597</div>
        </div>
      </div>
      <div class="header-actions">
        <button class="action-btn">···</button>
        <button class="action-btn">⭕</button>
      </div>
    </div>

    <!-- 顾问浮动 -->
    <div class="advisor-float">
      <div class="advisor-avatar"></div>
      <div class="advisor-status">在线咨询</div>
    </div>

    <!-- 会员卡 -->
    <div class="member-card">
      <div class="card-bg" style="background: linear-gradient(135deg, #a8edea, #667eea);">
        <div class="card-content">
          <div class="card-left">
            <div class="card-title">蓝星卡</div>
            <div class="card-level">L1普通会员</div>
          </div>
          <div class="card-right">
            <div class="planet-icon">🪐</div>
          </div>
        </div>
        <div class="card-footer">
          <div class="card-item">
            <span class="card-label">134****1597</span>
          </div>
          <div class="card-item">
            <span class="card-label">签发日期：2026年05月02日</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 我的资产 -->
    <div class="assets-section">
      <div class="asset-item">
        <div class="asset-icon">💰</div>
        <div class="asset-info">
          <div class="asset-value">0</div>
          <div class="asset-label">我的旅游基金</div>
        </div>
        <div class="asset-arrow">›</div>
      </div>
      <div class="asset-divider"></div>
      <div class="asset-item">
        <div class="asset-icon">🎫</div>
        <div class="asset-info">
          <div class="asset-value">0</div>
          <div class="asset-label">我的权益卡券</div>
        </div>
        <div class="asset-arrow">›</div>
      </div>
      <div class="asset-divider"></div>
      <div class="asset-item">
        <div class="asset-value">0</div>
        <div class="asset-label">未使用</div>
      </div>
    </div>

    <!-- 快捷入口 -->
    <div class="quick-entry">
      <div class="entry-icon">🎟️</div>
      <div class="entry-text">咨询行程 使用权益卡券</div>
      <button class="entry-btn">下单咨询 ›</button>
    </div>

    <!-- 我的行程 -->
    <div class="trips-section">
      <div class="section-header">
        <div class="section-title">我的行程</div>
        <div class="section-more">全部行程 ›</div>
      </div>
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <div class="empty-text">您还没有定制行程</div>
        <div class="empty-desc">先看看下面这些精心挑选的出行灵感吧！</div>
        <button class="go-custom-btn">去定制</button>
      </div>
    </div>

    <!-- 推荐内容 -->
    <div class="recommend-section">
      <div class="recommend-grid">
        <div class="recommend-item">
          <div class="item-img" style="background: linear-gradient(180deg, #ffecd2, #fcb69f);">
            <div class="item-tag">新疆</div>
          </div>
          <div class="item-content">
            <div class="item-title">看雪山住古城，一眼千年！退休必冲中亚5国</div>
            <div class="item-bottom">
              <div class="author">🍋 6人定制旅行</div>
            </div>
          </div>
        </div>
        <div class="recommend-item">
          <div class="item-img" style="background: linear-gradient(180deg, #a8edea, #667eea);">
            <div class="item-tag">新疆</div>
          </div>
          <div class="item-content">
            <div class="item-title">为什么此生一定要去一次葡萄牙？原来...</div>
            <div class="item-bottom">
              <div class="author">🍋 6人定制旅行</div>
            </div>
          </div>
        </div>
        <div class="recommend-item">
          <div class="item-img" style="background: linear-gradient(180deg, #f093fb, #fed6e3);">
            <div class="item-tag">新疆</div>
          </div>
          <div class="item-content">
            <div class="item-title">免签+乌兹别</div>
            <div class="item-bottom">
              <div class="author">🍋 6人</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 统计数据 -->
    <div class="stats-section">
      <div class="stat-item">
        <div class="stat-value">0</div>
        <div class="stat-label">行程</div>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item">
        <div class="stat-value">2</div>
        <div class="stat-label">关注</div>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item">
        <div class="stat-value">43</div>
        <div class="stat-label">浏览记录</div>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item">
        <div class="stat-value">2</div>
        <div class="stat-label">收藏</div>
      </div>
      <div class="stat-divider"></div>
      <div class="stat-item">
        <div class="stat-value">2</div>
        <div class="stat-label">心动</div>
      </div>
    </div>

    <!-- 常用工具 -->
    <div class="tools-section">
      <div class="section-title">常用工具</div>
      <div class="tools-grid">
        <div class="tool-item">
          <div class="tool-icon">📝</div>
          <div class="tool-label">提交需求</div>
        </div>
        <div class="tool-item">
          <div class="tool-icon">👤</div>
          <div class="tool-label">联系客服</div>
        </div>
        <div class="tool-item">
          <div class="tool-icon">📄</div>
          <div class="tool-label">签证</div>
        </div>
        <div class="tool-item">
          <div class="tool-icon">💬</div>
          <div class="tool-label">关注公众号</div>
        </div>
        <div class="tool-item">
          <div class="tool-icon">❓</div>
          <div class="tool-label">常见问题</div>
        </div>
        <div class="tool-item">
          <div class="tool-icon">📄</div>
          <div class="tool-label">用户协议</div>
        </div>
        <div class="tool-item">
          <div class="tool-icon">📄</div>
          <div class="tool-label">隐私政策</div>
        </div>
      </div>
    </div>

    <!-- 底部占位 -->
    <div class="bottom-space"></div>

    <TabBar />
  </div>
</template>

<script setup>
import TabBar from '../components/TabBar.vue'
</script>

<style scoped>
.profile-page {
  min-height: 100vh;
  background: #ffffff;
  padding-bottom: 80px;
}

.profile-header {
  background: #ffffff;
  padding: 40px 16px 16px 16px;
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  position: relative;
  border-bottom: 1px solid #f0f0f0;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.avatar {
  width: 56px;
  height: 56px;
  border-radius: 2px;
  background: linear-gradient(135deg, #f0f2f5, #ddd);
}

.phone {
  font-size: 16px;
  color: #333;
  font-weight: 600;
}

.header-actions {
  display: flex;
  gap: 6px;
}

.action-btn {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  width: 36px;
  height: 36px;
  border-radius: 2px;
  font-size: 16px;
  cursor: pointer;
}

.advisor-float {
  position: absolute;
  right: 16px;
  top: 70px;
  display: flex;
  align-items: center;
  gap: 8px;
  background: rgba(0,0,0,0.6);
  padding: 8px 14px;
  border-radius: 2px;
  z-index: 10;
}

.advisor-float .advisor-avatar {
  width: 36px;
  height: 36px;
  border-radius: 2px;
  background: linear-gradient(135deg, #ffecd2, #fcb69f);
}

.advisor-float .advisor-status {
  color: #ffffff;
  font-size: 13px;
  font-weight: 600;
}

.member-card {
  padding: 16px;
}

.card-bg {
  border-radius: 2px;
  padding: 20px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}

.card-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.card-left {
  color: #ffffff;
}

.card-title {
  font-size: 28px;
  font-weight: 700;
  margin-bottom: 6px;
}

.card-level {
  font-size: 15px;
  font-weight: 600;
}

.planet-icon {
  font-size: 56px;
}

.card-footer {
  display: flex;
  justify-content: space-between;
}

.card-label {
  color: #ffffff;
  font-size: 12px;
  opacity: 0.9;
}

.assets-section {
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 16px;
  display: flex;
  align-items: center;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.asset-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
}

.asset-icon {
  font-size: 28px;
  margin-bottom: 6px;
}

.asset-value {
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 4px;
  color: #333;
}

.asset-label {
  font-size: 12px;
  color: #999;
}

.asset-arrow {
  color: #999;
  font-size: 18px;
}

.asset-divider {
  width: 1px;
  height: 36px;
  background: #eee;
  margin: 0 14px;
}

.quick-entry {
  background: linear-gradient(135deg, #fff3e0, #fff9e6);
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.entry-icon {
  font-size: 28px;
}

.entry-text {
  flex: 1;
  font-size: 14px;
  font-weight: 600;
  color: #6d4c41;
}

.entry-btn {
  background: #fcb69f;
  color: #ffffff;
  border: none;
  padding: 8px 16px;
  border-radius: 2px;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
}

.trips-section {
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
}

.section-title {
  font-size: 15px;
  font-weight: 600;
  color: #333;
}

.section-more {
  font-size: 13px;
  color: #999;
}

.empty-state {
  text-align: center;
  padding: 24px 0;
}

.empty-icon {
  font-size: 56px;
  margin-bottom: 12px;
  opacity: 0.3;
}

.empty-text {
  font-size: 15px;
  color: #666;
  margin-bottom: 6px;
}

.empty-desc {
  font-size: 12px;
  color: #999;
  margin-bottom: 20px;
}

.go-custom-btn {
  background: #34C759;
  color: #ffffff;
  border: none;
  padding: 10px 32px;
  border-radius: 2px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.recommend-section {
  padding: 0 16px 12px 16px;
}

.recommend-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 8px;
}

.recommend-item {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.item-img {
  height: 100px;
  position: relative;
  padding: 8px;
}

.item-tag {
  position: absolute;
  bottom: 8px;
  left: 8px;
  background: rgba(0,0,0,0.6);
  color: #ffffff;
  padding: 3px 8px;
  border-radius: 2px;
  font-size: 10px;
}

.item-content {
  padding: 8px;
}

.item-title {
  font-size: 11px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 4px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  color: #333;
}

.item-bottom {
  display: flex;
  align-items: center;
  gap: 4px;
}

.author {
  font-size: 10px;
  color: #999;
}

.stats-section {
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 16px;
  display: flex;
  align-items: center;
  justify-content: space-around;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.stat-item {
  text-align: center;
}

.stat-value {
  font-size: 18px;
  font-weight: 700;
  margin-bottom: 4px;
  color: #333;
}

.stat-label {
  font-size: 11px;
  color: #999;
}

.stat-divider {
  width: 1px;
  height: 28px;
  background: #eee;
}

.tools-section {
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.tools-section .section-title {
  margin-bottom: 16px;
}

.tools-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.tool-item {
  text-align: center;
}

.tool-icon {
  font-size: 28px;
  margin-bottom: 6px;
}

.tool-label {
  font-size: 12px;
  color: #666;
}

.bottom-space {
  height: 20px;
}
</style>
