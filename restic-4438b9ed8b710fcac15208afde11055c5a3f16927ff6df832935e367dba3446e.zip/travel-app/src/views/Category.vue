<template>
  <div class="category-page">
    <!-- 顶部导航 -->
    <div class="page-header">
      <div class="header-actions">
        <button class="back-btn">‹</button>
        <button class="home-btn">🏠</button>
        <div class="logo">🌴 6人游</div>
        <button class="menu-btn">···</button>
        <button class="circle-btn">⭕</button>
      </div>
    </div>

    <!-- 轮播图 -->
    <div class="banner-section">
      <div class="banner-item">
        <div class="banner-img" style="background: linear-gradient(180deg, #34C759, #2ca349);">
          <div class="banner-text">出境游</div>
        </div>
      </div>
    </div>

    <!-- 标题卡片 -->
    <div class="title-card">
      <div class="title-info">
        <div class="title-left">
          <h1>出境游</h1>
          <span class="icon-btn">🔢</span>
        </div>
        <div class="title-right">
          <div class="stat">
            <div class="num">18</div>
            <div class="label">心动</div>
          </div>
        </div>
      </div>
      <p class="desc">世界那么大，想去的地方就别再等了。别把向往，永远只留在计划里。</p>
      <button class="follow-btn">+ 关注</button>
      <div class="action-btns">
        <button class="primary-btn">💬 咨询旅行顾问</button>
        <button class="secondary-btn">
          <span class="ai-icon">🤖</span>
          AI行程规划
        </button>
      </div>
    </div>

    <!-- 标签栏 -->
    <div class="tabs-section">
      <div class="tabs">
        <span class="tab active">精选</span>
      </div>
      <button class="search-btn">🔍</button>
    </div>

    <!-- 区域分类 -->
    <div class="region-tabs">
      <div class="region-tab">
        <span class="icon">🏰</span>
        <span>欧洲</span>
        <span class="arrow">›</span>
      </div>
      <div class="region-tab">
        <span class="icon">🦘</span>
        <span>大洋洲</span>
        <span class="arrow">›</span>
      </div>
      <div class="region-tab">
        <span class="icon">🛕</span>
        <span>东南亚</span>
        <span class="arrow">›</span>
      </div>
      <div class="region-tab">
        <span class="icon">🐪</span>
        <span>中东非</span>
        <span class="arrow">›</span>
      </div>
    </div>

    <!-- 视图切换 -->
    <div class="view-toggle-section">
      <div class="view-toggle">
        <button 
          :class="['toggle-btn', { active: viewMode === 'grid' }]"
          @click="viewMode = 'grid'"
        >▦ 两列</button>
        <button 
          :class="['toggle-btn', { active: viewMode === 'list' }]"
          @click="viewMode = 'list'"
        >☰ 一列</button>
      </div>
    </div>

    <!-- 文章列表 -->
    <div class="articles-grid" :class="{ 'list-mode': viewMode === 'list' }">
      <div v-for="(item, index) in articles" :key="index" class="article-card">
        <div class="card-img" :style="{ background: item.bg }">
          <div class="tags" v-if="item.tags">
            <span v-for="(tag, i) in item.tags" :key="i" class="tag">{{ tag }}</span>
          </div>
          <div class="location">{{ item.location }}</div>
        </div>
        <div class="card-content">
          <h4>{{ item.title }}</h4>
          <div class="card-footer">
            <div class="author">
              <span class="author-icon">{{ item.authorIcon }}</span>
              <span>{{ item.author }}</span>
            </div>
            <span class="likes">🤍 {{ item.likes }}</span>
          </div>
        </div>
        <div v-if="item.showAdvisor" class="advisor-float">
          <div class="advisor-avatar"></div>
          <div class="advisor-text">
            <div>在线</div>
            <div class="arrow">››</div>
          </div>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import TabBar from '../components/TabBar.vue'

const viewMode = ref('grid')

const articles = ref([
  {
    title: '家有6岁以上娃👨就酱冲新加坡~爆省心',
    bg: 'linear-gradient(180deg, #a8edea, #fed6e3)',
    location: '📍新加坡',
    tags: ['夜行动物园', '新加坡环球影城', '酒店限时优惠', '住3付2'],
    author: '6人游定制旅行',
    authorIcon: '🍋',
    likes: '99+',
    showAdvisor: false
  },
  {
    title: '芬兰追光，100%住玻璃屋❗就问你冲不冲',
    bg: 'linear-gradient(180deg, #2193b0, #6dd5ed)',
    location: '📍芬兰',
    tags: ['3晚圣诞-圣诞老人的故乡', '99%大曝光-直视北极极光', '100%保障-住极光玻璃屋', '更多体验...'],
    author: '6人游欧洲部',
    authorIcon: '🔮',
    likes: '99+',
    showAdvisor: true
  },
  {
    title: '新加坡亲子6日🌈住奢五+吃企鹅餐厅🧊圣淘沙6大乐园任选✨',
    bg: 'linear-gradient(180deg, #ffecd2, #fcb69f)',
    location: '📍新加坡',
    tags: ['圣淘沙岛', '飞禽公园', '国立大学', '学霸导游'],
    author: '6人游东南亚部',
    authorIcon: '🍋',
    likes: '99+',
    showAdvisor: false
  },
  {
    title: '寒假北海道,现在订比冬天便宜20%‼️变可退',
    bg: 'linear-gradient(180deg, #f093fb, #f5576c)',
    location: '📍日本',
    tags: ['登别温泉/小樽雪灯节/札幌雪祭/登别企鹅', '蟹公馆/旭川企鹅'],
    author: '6人游日',
    authorIcon: '🔮',
    likes: '2',
    showAdvisor: true
  }
])
</script>

<style scoped>
.category-page {
  min-height: 100vh;
  background: #ffffff;
  padding-bottom: 80px;
}

.page-header {
  position: relative;
  padding: 12px 16px;
  background: #ffffff;
  border-bottom: 1px solid #f0f0f0;
}

.header-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.back-btn,
.home-btn,
.menu-btn,
.circle-btn {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  width: 36px;
  height: 36px;
  border-radius: 2px;
  font-size: 18px;
  cursor: pointer;
}

.logo {
  font-size: 16px;
  font-weight: 700;
  color: #333;
}

.banner-section {
  padding: 12px 16px;
}

.banner-item {
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}

.banner-img {
  height: 120px;
  display: flex;
  align-items: flex-end;
  padding: 16px;
}

.banner-text {
  font-size: 24px;
  font-weight: 700;
  color: #ffffff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.title-card {
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.title-info {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 10px;
}

.title-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.title-left h1 {
  font-size: 22px;
  font-weight: 700;
  margin: 0;
  color: #333;
}

.icon-btn {
  background: #f5f5f5;
  padding: 3px 6px;
  border-radius: 2px;
  font-size: 12px;
  border: 1px solid #e0e0e0;
}

.stat {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
}

.stat .num {
  font-size: 20px;
  font-weight: 700;
  color: #333;
}

.stat .label {
  font-size: 11px;
  color: #999;
}

.desc {
  font-size: 13px;
  color: #666;
  line-height: 1.5;
  margin-bottom: 12px;
}

.follow-btn {
  width: 100%;
  padding: 8px;
  border: 1px solid #34C759;
  background: #ffffff;
  color: #34C759;
  border-radius: 2px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 10px;
  cursor: pointer;
}

.action-btns {
  display: flex;
  gap: 10px;
}

.primary-btn {
  flex: 2;
  background: #34C759;
  color: #ffffff;
  border: none;
  padding: 12px;
  border-radius: 2px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.secondary-btn {
  flex: 1;
  background: #fff3e0;
  border: none;
  padding: 12px;
  border-radius: 2px;
  font-size: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  cursor: pointer;
}

.ai-icon {
  font-size: 16px;
}

.tabs-section {
  background: #ffffff;
  padding: 10px 16px;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #f0f0f0;
}

.tabs {
  display: flex;
  gap: 8px;
}

.tab {
  padding: 6px 12px;
  font-size: 14px;
  color: #666;
  border-radius: 2px;
}

.tab.active {
  font-weight: 600;
  color: #333;
  position: relative;
}

.tab.active::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 2px;
  background: #34C759;
  border-radius: 2px;
}

.search-btn {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  width: 32px;
  height: 32px;
  border-radius: 2px;
  font-size: 14px;
  cursor: pointer;
}

.region-tabs {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  padding: 0 16px 12px 16px;
}

.region-tab {
  background: #ffffff;
  border-radius: 2px;
  padding: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.region-tab .icon {
  font-size: 18px;
}

.region-tab span {
  font-size: 13px;
  font-weight: 500;
  color: #333;
}

.region-tab .arrow {
  color: #999;
  font-size: 14px;
}

.view-toggle-section {
  padding: 0 16px 12px 16px;
}

.view-toggle {
  display: flex;
  gap: 8px;
  background: #f5f5f5;
  padding: 4px;
  border-radius: 2px;
  border: 1px solid #e0e0e0;
}

.toggle-btn {
  flex: 1;
  background: transparent;
  border: none;
  padding: 8px;
  border-radius: 2px;
  font-size: 13px;
  cursor: pointer;
  color: #666;
}

.toggle-btn.active {
  background: #ffffff;
  border: 1px solid #e0e0e0;
  color: #333;
  font-weight: 600;
}

.articles-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 10px;
  padding: 0 16px;
}

.articles-grid.list-mode {
  grid-template-columns: 1fr;
}

.article-card {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  position: relative;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.card-img {
  height: 180px;
  position: relative;
  padding: 8px;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}

.card-img .tags {
  position: absolute;
  top: 8px;
  left: 8px;
  right: 8px;
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
}

.card-img .tag {
  background: rgba(0,0,0,0.6);
  color: #ffffff;
  padding: 3px 6px;
  border-radius: 2px;
  font-size: 10px;
}

.location {
  color: #ffffff;
  font-size: 11px;
  font-weight: 600;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.card-content {
  padding: 10px;
}

.card-content h4 {
  font-size: 13px;
  font-weight: 600;
  line-height: 1.4;
  margin: 0 0 8px 0;
  color: #333;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  color: #999;
}

.author {
  display: flex;
  align-items: center;
  gap: 4px;
}

.author-icon {
  font-size: 12px;
}

.advisor-float {
  position: absolute;
  right: 8px;
  bottom: 70px;
  display: flex;
  align-items: center;
  gap: 6px;
  background: rgba(52, 199, 89, 0.95);
  padding: 6px 10px;
  border-radius: 2px;
}

.advisor-avatar {
  width: 32px;
  height: 32px;
  border-radius: 2px;
  background: linear-gradient(135deg, #ffecd2, #fcb69f);
}

.advisor-text {
  color: #ffffff;
  font-size: 11px;
  font-weight: 600;
  display: flex;
  flex-direction: column;
}

.advisor-text .arrow {
  font-size: 14px;
  font-weight: 400;
}
</style>
