<template>
  <div class="list-page">
    <!-- 顶部导航 -->
    <div class="page-header">
      <div class="header-actions">
        <button class="back-btn">‹</button>
        <button class="home-btn">🏠</button>
        <div class="logo">🌴 6人游</div>
        <button class="menu-btn">···</button>
        <button class="circle-btn">⭕</button>
      </div>
    </div>

    <!-- 轮播图 -->
    <div class="banner-section">
      <div class="banner-item">
        <div class="banner-img" style="background: linear-gradient(180deg, #a8edea, #fed6e3);">
          <div class="banner-text">泰国之旅</div>
        </div>
      </div>
    </div>

    <!-- 顾问卡片 -->
    <div class="advisor-card">
      <div class="advisor-info">
        <div class="avatar" style="background: linear-gradient(135deg, #ffecd2, #fcb69f);">🏛️</div>
        <div class="info">
          <h3>6人游泰国部</h3>
          <div class="meta">
            <span class="badge">💎 私享号: 1000019</span>
            <span class="qr">📷</span>
          </div>
          <p class="desc">高端游船、顶奢酒店、私密餐厅...惬意度假与深度体验，来泰国一次实现。</p>
        </div>
        <div class="stats">
          <div class="num">99+</div>
          <div class="label">心动</div>
        </div>
      </div>
      <button class="follow-btn">+ 关注</button>
      <div class="action-btns">
        <button class="primary-btn">💬 咨询旅行顾问</button>
        <button class="secondary-btn">
          <span class="ai-icon">🤖</span>
          AI行程规划
        </button>
      </div>
    </div>

    <!-- 标签和视图切换 -->
    <div class="filter-section">
      <div class="tabs">
        <span 
          v-for="(tab, index) in tabs" 
          :key="index"
          :class="['tab', { active: activeTab === index }]"
          @click="activeTab = index"
        >
          {{ tab }}
        </span>
        <button class="search-btn">🔍</button>
      </div>
      <div class="view-toggle">
        <button 
          :class="['toggle-btn', { active: viewMode === 'grid' }]"
          @click="viewMode = 'grid'"
        >▦</button>
        <button 
          :class="['toggle-btn', { active: viewMode === 'list' }]"
          @click="viewMode = 'list'"
        >☰</button>
      </div>
    </div>

    <!-- 内容列表 -->
    <div class="content-area">
      <div 
        v-if="viewMode === 'grid'"
        class="grid-layout"
      >
        <div 
          v-for="item in items" 
          :key="item.id" 
          class="grid-card"
        >
          <div class="card-img" :style="{ background: item.bg }">
            <div class="days-tag">{{ item.days }}</div>
            <div v-if="item.badge" class="special-badge">{{ item.badge }}</div>
          </div>
          <div class="card-content">
            <h4>{{ item.title }}</h4>
            <div class="tags" v-if="item.tags">
              <span v-for="(tag, i) in item.tags" :key="i" class="tag">{{ tag }}</span>
            </div>
            <div class="footer" v-if="item.author">
              <span class="author">{{ item.author }}</span>
              <span class="likes">🤍 {{ item.likes }}</span>
            </div>
          </div>
        </div>
      </div>

      <div 
        v-else
        class="list-layout"
      >
        <div 
          v-for="item in items" 
          :key="item.id" 
          class="list-card"
        >
          <div class="card-img" :style="{ background: item.bg }">
            <div class="days-tag">{{ item.days }}</div>
          </div>
          <div class="card-content">
            <h4>{{ item.title }}</h4>
            <div class="tags" v-if="item.tags">
              <span v-for="(tag, i) in item.tags" :key="i" class="tag">{{ tag }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>

    <TabBar />
  </div>
</template>

<script setup>
import { ref } from 'vue'
import TabBar from '../components/TabBar.vue'

const activeTab = ref(1)
const viewMode = ref('grid')
const tabs = ['精选', '线路推荐', '必玩体验', '必打卡景点']

const items = ref([
  {
    id: 1,
    title: '【陪你看世界·曼谷芭提雅6日】绿山动物园+萨美山岛出海+大象村咖啡+真理寺+日落悬崖餐厅发现',
    days: '6日',
    bg: 'linear-gradient(180deg, #2193b0, #6dd5ed)',
    tags: ['绿山动物园', '芭提雅萨美珊公主岛包船出海 (快艇往返)'],
    badge: null,
    author: '6人游定制旅行',
    likes: 55
  },
  {
    id: 2,
    title: '【泰兰德的夏天·曼谷芭堤雅6日】大皇宫-水门寺金色大佛-丹嫩沙朵水上市场-真理寺-格兰岛出海',
    days: '6日',
    bg: 'linear-gradient(180deg, #ffecd2, #fcb69f)',
    tags: ['大皇宫', '曼谷水门寺 (Wat Paknam) 金色大佛运河游船'],
    badge: null,
    author: '6人游定制旅行',
    likes: 44
  },
  {
    id: 3,
    title: '【海边日记·普吉亲子6日游】尼莫海豚馆+大象保护营+冰淇淋号网红滑梯游艇出海蜜月岛和蛋岛',
    days: '6日',
    bg: 'linear-gradient(180deg, #4facfe, #00f2fe)',
    tags: [],
    badge: null,
    author: '6人游东南亚部',
    likes: 36
  },
  {
    id: 4,
    title: '🌴【清迈遛娃炸攻略！6天把假期过成童话，这才是亲子游天花板吧！】',
    days: '6日',
    bg: 'linear-gradient(180deg, #f093fb, #f5576c)',
    tags: [],
    badge: '免签',
    author: '6人游定制旅行',
    likes: 69
  },
  {
    id: 5,
    title: '摸象+住私墅+看蓝眼泪！带6岁娃普吉天花板',
    days: '5日',
    bg: 'linear-gradient(180deg, #667eea, #764ba2)',
    tags: [],
    badge: null,
    author: '6人游东南亚部',
    likes: 44
  },
  {
    id: 6,
    title: '普吉+斯米兰双岛 🐬限时开放，年轻人性价比首选',
    days: '6日',
    bg: 'linear-gradient(180deg, #a8edea, #fed6e3)',
    tags: [],
    badge: '限时开放',
    author: '6人游东南亚部',
    likes: 74
  }
])
</script>

<style scoped>
.list-page {
  min-height: 100vh;
  background: #ffffff;
  padding-bottom: 80px;
}

.page-header {
  position: relative;
  padding: 12px 16px;
  background: #ffffff;
  border-bottom: 1px solid #f0f0f0;
}

.header-actions {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.back-btn,
.home-btn,
.menu-btn,
.circle-btn {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  width: 36px;
  height: 36px;
  border-radius: 2px;
  font-size: 18px;
  cursor: pointer;
}

.logo {
  font-size: 16px;
  font-weight: 700;
  color: #333;
}

.banner-section {
  padding: 12px 16px;
}

.banner-item {
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
}

.banner-img {
  height: 140px;
  display: flex;
  align-items: flex-end;
  padding: 16px;
}

.banner-text {
  font-size: 20px;
  font-weight: 700;
  color: #ffffff;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.advisor-card {
  background: #ffffff;
  margin: 0 16px 12px 16px;
  border-radius: 2px;
  padding: 16px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.advisor-info {
  display: flex;
  gap: 12px;
  margin-bottom: 12px;
}

.avatar {
  width: 56px;
  height: 56px;
  border-radius: 2px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
  flex-shrink: 0;
}

.info {
  flex: 1;
}

.info h3 {
  font-size: 16px;
  font-weight: 700;
  margin-bottom: 6px;
  color: #333;
}

.meta {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 6px;
}

.badge {
  background: #fff3e0;
  color: #ff9800;
  padding: 3px 8px;
  border-radius: 2px;
  font-size: 11px;
}

.qr {
  background: #f5f5f5;
  padding: 3px 6px;
  border-radius: 2px;
  font-size: 12px;
}

.desc {
  font-size: 12px;
  color: #666;
  line-height: 1.5;
}

.stats {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.num {
  font-size: 20px;
  font-weight: 700;
  color: #333;
}

.label {
  font-size: 11px;
  color: #999;
}

.follow-btn {
  width: 100%;
  padding: 8px;
  border: 1px solid #34C759;
  background: #ffffff;
  color: #34C759;
  border-radius: 2px;
  font-size: 13px;
  font-weight: 600;
  margin-bottom: 10px;
  cursor: pointer;
}

.action-btns {
  display: flex;
  gap: 10px;
}

.primary-btn {
  flex: 2;
  background: #34C759;
  color: #ffffff;
  border: none;
  padding: 12px;
  border-radius: 2px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.secondary-btn {
  flex: 1;
  background: #fff3e0;
  border: none;
  padding: 12px;
  border-radius: 2px;
  font-size: 12px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  cursor: pointer;
}

.ai-icon {
  font-size: 16px;
}

.filter-section {
  background: #ffffff;
  padding: 10px 16px;
  margin-bottom: 10px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  border-bottom: 1px solid #f0f0f0;
}

.tabs {
  display: flex;
  gap: 8px;
  overflow-x: auto;
  flex: 1;
}

.tab {
  flex-shrink: 0;
  padding: 6px 12px;
  font-size: 14px;
  color: #666;
  border-radius: 2px;
}

.tab.active {
  font-weight: 600;
  color: #333;
  position: relative;
}

.tab.active::after {
  content: '';
  position: absolute;
  bottom: -4px;
  left: 50%;
  transform: translateX(-50%);
  width: 20px;
  height: 2px;
  background: #34C759;
  border-radius: 2px;
}

.search-btn {
  background: #f5f5f5;
  border: 1px solid #e0e0e0;
  width: 32px;
  height: 32px;
  border-radius: 2px;
  font-size: 14px;
  margin-left: 10px;
  cursor: pointer;
}

.view-toggle {
  display: flex;
  gap: 4px;
  background: #f5f5f5;
  padding: 4px;
  border-radius: 2px;
  margin-left: 10px;
  border: 1px solid #e0e0e0;
}

.toggle-btn {
  background: transparent;
  border: none;
  width: 28px;
  height: 28px;
  border-radius: 2px;
  font-size: 14px;
  cursor: pointer;
}

.toggle-btn.active {
  background: #ffffff;
  border: 1px solid #e0e0e0;
}

.content-area {
  padding: 0 16px;
}

.grid-layout {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

.grid-card {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.card-img {
  height: 160px;
  position: relative;
}

.days-tag {
  position: absolute;
  bottom: 8px;
  left: 8px;
  color: #ffffff;
  font-size: 28px;
  font-weight: 700;
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
}

.special-badge {
  position: absolute;
  top: 8px;
  left: 8px;
  background: #ff6b35;
  color: #ffffff;
  padding: 3px 8px;
  border-radius: 2px;
  font-size: 11px;
  font-weight: 600;
}

.card-content {
  padding: 10px;
}

.card-content h4 {
  font-size: 13px;
  font-weight: 600;
  line-height: 1.4;
  margin-bottom: 6px;
  color: #333;
}

.tags {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  margin-bottom: 6px;
}

.tag {
  background: #f5f5f5;
  padding: 3px 6px;
  border-radius: 2px;
  font-size: 10px;
  color: #666;
}

.footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 11px;
  color: #999;
}

.list-layout {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.list-card {
  background: #ffffff;
  border-radius: 2px;
  overflow: hidden;
  display: flex;
  box-shadow: 0 1px 3px rgba(0,0,0,0.06);
  border: 1px solid #f0f0f0;
}

.list-card .card-img {
  width: 120px;
  height: 140px;
  flex-shrink: 0;
}

.list-card .card-content {
  flex: 1;
  padding: 10px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}
</style>
