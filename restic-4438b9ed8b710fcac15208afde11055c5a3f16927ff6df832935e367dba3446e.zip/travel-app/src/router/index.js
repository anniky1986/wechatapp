import { createRouter, createWebHashHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Advisor from '../views/Advisor.vue'
import Luxury from '../views/Luxury.vue'
import Discovery from '../views/Discovery.vue'
import Itinerary from '../views/Itinerary.vue'
import Custom from '../views/Custom.vue'
import List from '../views/List.vue'

const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/advisor', name: 'Advisor', component: Advisor },
  { path: '/luxury', name: 'Luxury', component: Luxury },
  { path: '/discovery', name: 'Discovery', component: Discovery },
  { path: '/itinerary', name: 'Itinerary', component: Itinerary },
  { path: '/custom', name: 'Custom', component: Custom },
  { path: '/list', name: 'List', component: List },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
