<template>
  <el-dialog
    v-model="visible"
    :title="isEdit ? '编辑模板' : '创建新模板'"
    width="800px"
    top="5vh"
    :close-on-click-modal="false"
    destroy-on-close
    @close="$emit('close')"
  >
    <div class="creator-layout">
      <div class="creator-form">
        <el-form :model="form" label-width="80px" size="small">
          <el-form-item label="模板名称" required>
            <el-input v-model="form.name" placeholder="请输入模板名称" />
          </el-form-item>
          <el-form-item label="模板分类" required>
            <el-select v-model="form.category" placeholder="选择分类" style="width: 100%;">
              <el-option
                v-for="cat in categoryOptions"
                :key="cat.key"
                :label="cat.label"
                :value="cat.key"
              />
            </el-select>
          </el-form-item>
          <el-form-item label="标签">
            <el-select
              v-model="form.tags"
              multiple
              filterable
              allow-create
              default-first-option
              placeholder="输入标签后回车"
              style="width: 100%;"
            >
              <el-option v-for="tag in commonTags" :key="tag" :label="tag" :value="tag" />
            </el-select>
          </el-form-item>
          <el-form-item label="HTML代码" required>
            <el-input
              v-model="form.html"
              type="textarea"
              :rows="12"
              placeholder="输入HTML代码，使用双花括号标记可编辑区域"
              spellcheck="false"
              class="html-textarea"
            />
          </el-form-item>
          <el-form-item>
            <div class="form-tips">
              <p>💡 使用 <code v-pre>{{占位符}}</code> 标记可编辑区域，插入模板时会弹出填写表单</p>
              <p>⚠️ 请使用内联样式（style属性），确保兼容微信公众号</p>
            </div>
          </el-form-item>
        </el-form>
      </div>

      <div class="creator-preview">
        <div class="preview-header">实时预览</div>
        <div class="preview-body">
          <div v-if="form.html" class="preview-content" v-html="previewHtml"></div>
          <div v-else class="preview-empty">在左侧输入HTML代码后预览效果</div>
        </div>
        <div v-if="editableZones.length" class="preview-zones">
          <div class="zones-title">可编辑区域</div>
          <el-tag v-for="zone in editableZones" :key="zone" size="small" type="info" style="margin: 2px;">
            {{ zone }}
          </el-tag>
        </div>
      </div>
    </div>

    <template #footer>
      <el-button @click="visible = false">取消</el-button>
      <el-button type="primary" @click="onSave" :disabled="!canSave">
        {{ isEdit ? '保存修改' : '创建模板' }}
      </el-button>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { categories, saveCustomTemplate } from '../templates/index.js'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  editTemplate: { type: Object, default: null }
})

const emit = defineEmits(['update:modelValue', 'close', 'saved'])

const visible = computed({
  get: () => props.modelValue,
  set: (val) => emit('update:modelValue', val)
})

const isEdit = computed(() => !!props.editTemplate)

const categoryOptions = categories.filter(c => c.key !== 'custom')

const commonTags = ['标题', '卡片', '分割线', '图文', '引用', '渐变', '简约', '阴影', '背景', '圆角', '提示', '警告']

const form = ref({
  name: '',
  category: 'card',
  tags: [],
  html: ''
})

watch(() => props.modelValue, (val) => {
  if (val && props.editTemplate) {
    form.value = {
      name: props.editTemplate.name,
      category: props.editTemplate.category,
      tags: [...(props.editTemplate.tags || [])],
      html: props.editTemplate.html
    }
  } else if (val) {
    form.value = { name: '', category: 'card', tags: [], html: '' }
  }
})

const previewHtml = computed(() => {
  let html = form.value.html
  html = html.replace(/\{\{(.+?)\}\}/g, '<span style="color:#409eff;font-style:italic;border:1px dashed #409eff;padding:0 4px;border-radius:3px;">$1</span>')
  return html
})

const editableZones = computed(() => {
  const zones = []
  const regex = /\{\{(.+?)\}\}/g
  let match
  while ((match = regex.exec(form.value.html)) !== null) {
    if (!zones.includes(match[1])) zones.push(match[1])
  }
  return zones
})

const canSave = computed(() => {
  return form.value.name.trim() && form.value.html.trim() && form.value.category
})

function onSave() {
  if (!canSave.value) return

  const template = {
    id: isEdit.value
      ? props.editTemplate.id
      : 'custom-' + Date.now(),
    name: form.value.name.trim(),
    category: form.value.category,
    tags: form.value.tags,
    html: form.value.html,
    source: 'custom'
  }

  saveCustomTemplate(template)
  visible.value = false
  ElMessage.success(isEdit.value ? '模板已更新' : '模板已创建')
  emit('saved')
}
</script>

<style scoped>
.creator-layout {
  display: flex;
  gap: 16px;
  min-height: 400px;
}

.creator-form {
  flex: 1;
  min-width: 0;
}

.creator-preview {
  width: 300px;
  flex-shrink: 0;
  border: 1px solid #e0e0e0;
  border-radius: 6px;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.preview-header {
  padding: 8px 12px;
  font-size: 13px;
  font-weight: 600;
  color: #606266;
  background: #f5f7fa;
  border-bottom: 1px solid #e0e0e0;
}

.preview-body {
  flex: 1;
  padding: 12px;
  overflow-y: auto;
  background: #fff;
}

.preview-content {
  font-size: 13px;
  line-height: 1.6;
}

.preview-content :deep(img) {
  max-width: 100%;
}

.preview-empty {
  color: #c0c4cc;
  text-align: center;
  padding: 40px 20px;
  font-size: 13px;
}

.preview-zones {
  padding: 8px 12px;
  border-top: 1px solid #e0e0e0;
  background: #fafafa;
}

.zones-title {
  font-size: 11px;
  color: #909399;
  margin-bottom: 4px;
}

.form-tips {
  font-size: 12px;
  color: #909399;
  line-height: 1.8;
}

.form-tips code {
  background: #f5f7fa;
  padding: 1px 4px;
  border-radius: 3px;
  color: #409eff;
}

.html-textarea :deep(.el-textarea__inner) {
  font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
  font-size: 12px;
  line-height: 1.6;
}
</style>
