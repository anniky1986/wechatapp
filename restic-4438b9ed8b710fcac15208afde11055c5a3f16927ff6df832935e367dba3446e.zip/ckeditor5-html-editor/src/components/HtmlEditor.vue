<template>
  <div class="html-editor-wrapper">
    <div class="editor-main">
      <div class="editor-container" ref="editorContainer">
        <ckeditor
          v-if="isEditorReady"
          v-model="editorData"
          :editor="ClassicEditor"
          :config="editorConfig"
          @ready="onEditorReady"
        />
      </div>

      <TemplatePanel
        :visible="templatePanelVisible"
        @close="templatePanelVisible = false"
        @insert="onTemplateInsert"
        @create="creatorVisible = true"
        @edit="onEditTemplate"
      />
    </div>

    <button
      class="template-toggle-btn"
      :class="{ active: templatePanelVisible }"
      @click="templatePanelVisible = !templatePanelVisible"
      title="模板面板"
    >
      <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M3 3h5v5H3V3Zm7 0h5v5h-5V3Zm0 7h5v5h-5v-5Zm-7 0h5v5H3v-5ZM4 4v3h3V4H4Zm7 0v3h3V4h-3Zm0 7v3h3v-3h-3ZM4 11v3h3v-3H4Z"/></svg>
    </button>

    <TemplateCreator
      v-model="creatorVisible"
      :edit-template="editingTemplate"
      @saved="onTemplateSaved"
    />

    <div class="source-editing-overlay" v-if="isSourceMode">
      <div class="source-editing-panel">
        <div class="source-panel-header">
          <div class="source-panel-tabs">
            <button
              class="source-tab"
              :class="{ active: sourceTab === 'code' }"
              @click="sourceTab = 'code'"
            >
              <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M12.87 12.19a.75.75 0 0 1 0 1.06l-3.5 3.5a.75.75 0 0 1-1.06 0l-3.5-3.5a.75.75 0 1 1 1.06-1.06l2.97 2.97 2.97-2.97a.75.75 0 0 1 1.06 0Zm0-4.38a.75.75 0 0 1-1.06 0L8.84 6.84 5.87 9.81a.75.75 0 0 1-1.06-1.06l3.5-3.5a.75.75 0 0 1 1.06 0l3.5 3.5a.75.75 0 0 1 0 1.06Z"/></svg>
              源码编辑
            </button>
            <button
              class="source-tab"
              :class="{ active: sourceTab === 'preview' }"
              @click="switchToPreview"
            >
              <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M10 3.5c4.97 0 9 3.185 9 6.5s-4.03 6.5-9 6.5-9-3.185-9-6.5 4.03-6.5 9-6.5Zm0 1.5c-4.14 0-7.5 2.462-7.5 5s3.36 5 7.5 5 7.5-2.462 7.5-5-3.36-5-7.5-5Zm0 1a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 1.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"/></svg>
              预览效果
            </button>
          </div>
          <div class="source-panel-actions">
            <button class="source-action-btn" @click="formatSourceCode" title="格式化代码">
              <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M2 3.75A.75.75 0 0 1 2.75 3h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 3.75Zm0 5A.75.75 0 0 1 2.75 8h10.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 8.75ZM2.75 13a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Zm10-1.25a.75.75 0 0 1 .75.75v1.25h1.25a.75.75 0 0 1 0 1.5H13.5v1.25a.75.75 0 0 1-1.5 0v-1.25H10.75a.75.75 0 0 1 0-1.5H12V13a.75.75 0 0 1 .75-.75Z"/></svg>
              格式化
            </button>
            <button class="source-action-btn" @click="copySourceCode" title="复制源码">
              <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M6 2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H6Zm0 1.5h8a.5.5 0 0 1 .5.5v10a.5.5 0 0 1-.5.5H6a.5.5 0 0 1-.5-.5V4a.5.5 0 0 1 .5-.5ZM3.5 6A.75.75 0 0 0 2 6v10a2 2 0 0 0 2 2h7.25a.75.75 0 0 0 0-1.5H4a.5.5 0 0 1-.5-.5V6Z"/></svg>
              复制
            </button>
            <span class="source-status" :class="{ modified: sourceModified }">
              {{ sourceModified ? '已修改' : '未修改' }}
            </span>
          </div>
        </div>

        <div class="source-panel-body" v-show="sourceTab === 'code'">
          <div ref="codeMirrorContainer" class="codemirror-host"></div>
        </div>

        <div class="source-panel-body preview-body" v-show="sourceTab === 'preview'">
          <iframe
            ref="inlinePreviewIframe"
            class="inline-preview-iframe"
            sandbox="allow-same-origin"
          ></iframe>
        </div>

        <div class="source-panel-footer">
          <span class="source-hint">按 Ctrl+Z 撤销 · Ctrl+Y 重做 · 修改后点击"应用修改"同步到编辑器</span>
          <div class="source-footer-actions">
            <button class="source-btn source-btn-cancel" @click="cancelSourceEdit">取消</button>
            <button class="source-btn source-btn-apply" @click="applySourceCode">
              <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M17.28 5.22a.75.75 0 0 1 0 1.06l-9 9a.75.75 0 0 1-1.06 0l-4.5-4.5a.75.75 0 1 1 1.06-1.06L7.5 13.44l8.72-8.72a.75.75 0 0 1 1.06 0Z"/></svg>
              应用修改
            </button>
          </div>
        </div>
      </div>
    </div>

    <el-dialog
      v-model="previewDialogVisible"
      title="HTML 预览效果"
      width="85%"
      top="3vh"
      destroy-on-close
    >
      <div class="preview-container">
        <iframe
          ref="previewIframe"
          class="preview-iframe"
          sandbox="allow-same-origin"
        ></iframe>
      </div>
      <template #footer>
        <el-button @click="previewDialogVisible = false">关闭</el-button>
      </template>
    </el-dialog>

    <el-dialog
      v-model="saveDialogVisible"
      title="保存到数据库"
      width="50%"
      destroy-on-close
    >
      <el-form label-width="100px">
        <el-form-item label="内容名称">
          <el-input v-model="saveForm.name" placeholder="请输入内容名称" />
        </el-form-item>
        <el-form-item label="内容描述">
          <el-input
            v-model="saveForm.description"
            type="textarea"
            :rows="3"
            placeholder="请输入内容描述"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="saveDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmSave">确认保存</el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, computed, nextTick, onBeforeUnmount, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Ckeditor } from '@ckeditor/ckeditor5-vue'
import {
  ClassicEditor,
  Essentials,
  Paragraph,
  Heading,
  Bold,
  Italic,
  Underline,
  Strikethrough,
  Code,
  Subscript,
  Superscript,
  Link,
  List,
  Alignment,
  Indent,
  IndentBlock,
  BlockQuote,
  Table,
  TableToolbar,
  Image,
  ImageToolbar,
  ImageCaption,
  ImageStyle,
  ImageResize,
  ImageInsert,
  MediaEmbed,
  Undo,
  GeneralHtmlSupport,
  SourceEditing,
  Font,
  RemoveFormat,
  Highlight,
  TodoList,
  Style,
  SpecialCharacters,
  SpecialCharactersEmoji,
  SpecialCharactersText
} from 'ckeditor5'

import 'ckeditor5/ckeditor5.css'
import { EditorView, keymap, lineNumbers, highlightActiveLineGutter, highlightActiveLine, drawSelection, rectangularSelection, highlightSpecialChars } from '@codemirror/view'
import { EditorState } from '@codemirror/state'
import { html } from '@codemirror/lang-html'
import { oneDark } from '@codemirror/theme-one-dark'
import { defaultKeymap, history, historyKeymap, indentWithTab } from '@codemirror/commands'
import { syntaxHighlighting, defaultHighlightStyle, bracketMatching, foldGutter, indentOnInput, foldKeymap } from '@codemirror/language'
import { searchKeymap, highlightSelectionMatches } from '@codemirror/search'
import { autocompletion, completionKeymap, closeBrackets, closeBracketsKeymap } from '@codemirror/autocomplete'
import TemplatePanel from './TemplatePanel.vue'
import TemplateCreator from './TemplateCreator.vue'

const isEditorReady = ref(true)
const isSourceMode = ref(false)
const sourceTab = ref('code')
const templatePanelVisible = ref(false)
const creatorVisible = ref(false)
const editingTemplate = ref(null)
const editorData = ref(`<h1>CKEditor5 HTML 编辑器演示</h1>
<p>这是一个基于 <strong>CKEditor 5</strong> 开源版本 + <em>GeneralHtmlSupport</em> + <em>SourceEditing</em> 插件的 HTML 编辑器。</p>

<h2>功能特性</h2>
<div class="feature-card" style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin: 12px 0; background: #fafafa;">
  <h3 style="color: #409eff;">🎨 可视化编辑</h3>
  <p>所见即所得的富文本编辑体验，支持标题、加粗、斜体、列表、表格等常用格式。</p>
</div>

<div class="feature-card" style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin: 12px 0; background: #fafafa;">
  <h3 style="color: #67c23a;">📝 HTML 源码编辑</h3>
  <p>点击工具栏的 <strong>"Source"</strong> 按钮进入源码编辑模式，编辑器内容区域会被替换为代码编辑器。</p>
  <p>源码编辑器基于 <strong>CodeMirror 6</strong>，提供语法高亮、行号、代码折叠、自动补全等功能，体验接近商用版 SourceEditingEnhanced。</p>
</div>

<div class="feature-card" style="border: 1px solid #e0e0e0; border-radius: 8px; padding: 16px; margin: 12px 0; background: #fafafa;">
  <h3 style="color: #e6a23c;">👁️ HTML 预览</h3>
  <p>在源码编辑模式中，可以切换到"预览效果"标签页实时查看 HTML 渲染效果。</p>
</div>

<section data-custom="demo" class="custom-section" style="margin-top: 20px; padding: 15px; border-left: 4px solid #409eff; background: #ecf5ff;">
  <h3>自定义 HTML 元素演示</h3>
  <p>这段内容使用了 <code>&lt;section&gt;</code>、<code>data-custom</code> 属性和自定义样式，<br/>通过 <strong>GeneralHtmlSupport</strong> 插件，这些自定义 HTML 标记会被完整保留。</p>
</section>

<blockquote>
  <p>💡 提示：点击工具栏的 "Source" 按钮进入源码编辑模式，在编辑器内容区域中直接编辑 HTML 代码，并可切换预览效果。</p>
</blockquote>

<table>
  <thead>
    <tr><th>功能</th><th>开源版 (本方案)</th><th>商用版</th></tr>
  </thead>
  <tbody>
    <tr><td>基础富文本编辑</td><td>✅</td><td>✅</td></tr>
    <tr><td>General HTML Support</td><td>✅</td><td>✅</td></tr>
    <tr><td>源码编辑 (内嵌面板)</td><td>✅</td><td>✅ (弹窗)</td></tr>
    <tr><td>语法高亮</td><td>✅ (CodeMirror 6)</td><td>✅</td></tr>
    <tr><td>代码折叠</td><td>✅ (CodeMirror 6)</td><td>✅</td></tr>
    <tr><td>自动补全</td><td>✅ (CodeMirror 6)</td><td>✅</td></tr>
    <tr><td>源码/预览切换</td><td>✅</td><td>✅</td></tr>
    <tr><td>行号显示</td><td>✅ (CodeMirror 6)</td><td>✅</td></tr>
  </tbody>
</table>`)

const sourceCode = ref('')
const sourceModified = ref(false)
const originalSourceCode = ref('')
const previewDialogVisible = ref(false)
const saveDialogVisible = ref(false)
const previewIframe = ref(null)
const inlinePreviewIframe = ref(null)
const editorInstance = ref(null)
const editorContainer = ref(null)
const codeMirrorContainer = ref(null)
const saveForm = ref({ name: '', description: '' })

let codeMirrorView = null

const editorConfig = computed(() => ({
  licenseKey: 'GPL',
  plugins: [
    Essentials,
    Paragraph,
    Heading,
    Bold,
    Italic,
    Underline,
    Strikethrough,
    Code,
    Subscript,
    Superscript,
    Link,
    List,
    TodoList,
    Alignment,
    Indent,
    IndentBlock,
    BlockQuote,
    Table,
    TableToolbar,
    Image,
    ImageToolbar,
    ImageCaption,
    ImageStyle,
    ImageResize,
    ImageInsert,
    MediaEmbed,
    Undo,
    GeneralHtmlSupport,
    SourceEditing,
    Font,
    RemoveFormat,
    Highlight,
    Style,
    SpecialCharacters,
    SpecialCharactersEmoji,
    SpecialCharactersText
  ],
  toolbar: [
    'undo', 'redo', '|',
    'heading', '|',
    'bold', 'italic', 'underline', 'strikethrough', 'code', 'removeFormat', '|',
    'fontSize', 'fontFamily', 'fontColor', 'fontBackgroundColor', '|',
    'bulletedList', 'numberedList', 'todoList', '|',
    'outdent', 'indent', '|',
    'alignment', '|',
    'link', 'insertImage', 'mediaEmbed', '|',
    'blockQuote', 'insertTable', '|',
    'highlight', 'style', '|',
    'sourceEditing', '|',
    'specialCharacters'
  ],
  htmlSupport: {
    allow: [
      {
        name: /.*/,
        attributes: true,
        classes: true,
        styles: true
      }
    ],
    disallow: [
      {
        name: /.*/,
        attributes: [
          { key: /^on.*$/, value: true }
        ]
      }
    ]
  },
  image: {
    toolbar: [
      'imageStyle:inline',
      'imageStyle:block',
      'imageStyle:side',
      '|',
      'toggleImageCaption',
      'imageTextAlternative'
    ]
  },
  table: {
    contentToolbar: [
      'tableColumn',
      'tableRow',
      'mergeTableCells'
    ]
  }
}))

function onEditorReady(editor) {
  editorInstance.value = editor

  const sourceEditingPlugin = editor.plugins.get('SourceEditing')
  if (sourceEditingPlugin) {
    sourceEditingPlugin.on('change:isSourceEditingMode', (evt, name, isSourceEditingMode) => {
      if (isSourceEditingMode) {
        nextTick(() => {
          injectCodeMirror()
        })
      } else {
        destroyCodeMirror()
        isSourceMode.value = false
      }
    })
  }
}

function injectCodeMirror() {
  const editor = editorInstance.value
  if (!editor) return

  const editingView = editor.editing.view
  const domRoots = editingView.domRoots

  for (const [rootName, domRootElement] of domRoots) {
    const sourceEditingArea = domRootElement.parentElement
    if (!sourceEditingArea || !sourceEditingArea.classList.contains('ck-source-editing-area')) {
      continue
    }

    const textarea = sourceEditingArea.querySelector('textarea')
    if (!textarea) continue

    sourceCode.value = textarea.value
    originalSourceCode.value = textarea.value
    sourceModified.value = false
    sourceTab.value = 'code'
    isSourceMode.value = true

    textarea.style.display = 'none'

    sourceEditingArea.style.position = 'relative'

    const cmHost = document.createElement('div')
    cmHost.className = 'cm-host-container'
    cmHost.style.cssText = 'position:absolute;top:0;left:0;right:0;bottom:0;z-index:1;'
    sourceEditingArea.appendChild(cmHost)

    const tabHeader = createTabHeader(sourceEditingArea)
    cmHost.appendChild(tabHeader)

    const cmBody = document.createElement('div')
    cmBody.className = 'cm-body-container'
    cmBody.style.cssText = 'position:absolute;top:40px;left:0;right:0;bottom:44px;'
    cmHost.appendChild(cmBody)

    const footer = createFooter(sourceEditingArea, textarea)
    cmHost.appendChild(footer)

    createCodeMirrorInstance(cmBody, textarea, sourceEditingArea)
  }
}

function createTabHeader(sourceEditingArea) {
  const header = document.createElement('div')
  header.className = 'source-panel-header'
  header.innerHTML = `
    <div class="source-panel-tabs">
      <button class="source-tab active" data-tab="code">
        <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M12.87 12.19a.75.75 0 0 1 0 1.06l-3.5 3.5a.75.75 0 0 1-1.06 0l-3.5-3.5a.75.75 0 1 1 1.06-1.06l2.97 2.97 2.97-2.97a.75.75 0 0 1 1.06 0Zm0-4.38a.75.75 0 0 1-1.06 0L8.84 6.84 5.87 9.81a.75.75 0 0 1-1.06-1.06l3.5-3.5a.75.75 0 0 1 1.06 0l3.5 3.5a.75.75 0 0 1 0 1.06Z"/></svg>
        源码编辑
      </button>
      <button class="source-tab" data-tab="preview">
        <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><path d="M10 3.5c4.97 0 9 3.185 9 6.5s-4.03 6.5-9 6.5-9-3.185-9-6.5 4.03-6.5 9-6.5Zm0 1.5c-4.14 0-7.5 2.462-7.5 5s3.36 5 7.5 5 7.5-2.462 7.5-5-3.36-5-7.5-5Zm0 1a4 4 0 1 1 0 8 4 4 0 0 1 0-8Zm0 1.5a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5Z"/></svg>
        预览效果
      </button>
    </div>
    <div class="source-panel-actions">
      <button class="source-action-btn" data-action="format" title="格式化代码">
        <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M2 3.75A.75.75 0 0 1 2.75 3h14.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 3.75Zm0 5A.75.75 0 0 1 2.75 8h10.5a.75.75 0 0 1 0 1.5H2.75A.75.75 0 0 1 2 8.75ZM2.75 13a.75.75 0 0 0 0 1.5h6.5a.75.75 0 0 0 0-1.5h-6.5Zm10-1.25a.75.75 0 0 1 .75.75v1.25h1.25a.75.75 0 0 1 0 1.5H13.5v1.25a.75.75 0 0 1-1.5 0v-1.25H10.75a.75.75 0 0 1 0-1.5H12V13a.75.75 0 0 1 .75-.75Z"/></svg>
        格式化
      </button>
      <button class="source-action-btn" data-action="copy" title="复制源码">
        <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M6 2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H6Zm0 1.5h8a.5.5 0 0 1 .5.5v10a.5.5 0 0 1-.5.5H6a.5.5 0 0 1-.5-.5V4a.5.5 0 0 1 .5-.5ZM3.5 6A.75.75 0 0 0 2 6v10a2 2 0 0 0 2 2h7.25a.75.75 0 0 0 0-1.5H4a.5.5 0 0 1-.5-.5V6Z"/></svg>
        复制
      </button>
      <span class="source-status">未修改</span>
    </div>
  `

  const tabs = header.querySelectorAll('.source-tab')
  const codeTab = tabs[0]
  const previewTab = tabs[1]
  const cmHost = header.parentElement
  const cmBody = cmHost.querySelector('.cm-body-container')
  const previewContainer = cmHost.querySelector('.preview-container')

  codeTab.addEventListener('click', () => {
    codeTab.classList.add('active')
    previewTab.classList.remove('active')
    if (cmBody) cmBody.style.display = ''
    if (previewContainer) previewContainer.style.display = 'none'
    if (codeMirrorView) codeMirrorView.focus()
  })

  previewTab.addEventListener('click', () => {
    previewTab.classList.add('active')
    codeTab.classList.remove('active')
    if (cmBody) cmBody.style.display = 'none'
    if (!previewContainer) {
      const pc = document.createElement('div')
      pc.className = 'preview-container'
      pc.style.cssText = 'position:absolute;top:0;left:0;right:0;bottom:0;background:#fff;'
      const iframe = document.createElement('iframe')
      iframe.className = 'inline-preview-iframe'
      iframe.style.cssText = 'width:100%;height:100%;border:none;'
      iframe.setAttribute('sandbox', 'allow-same-origin')
      pc.appendChild(iframe)
      cmHost.appendChild(pc)

      const currentCode = codeMirrorView ? codeMirrorView.state.doc.toString() : sourceCode.value
      iframe.srcdoc = getPreviewHtml(currentCode)
    } else {
      previewContainer.style.display = ''
      const currentCode = codeMirrorView ? codeMirrorView.state.doc.toString() : sourceCode.value
      const iframe = previewContainer.querySelector('iframe')
      if (iframe) iframe.srcdoc = getPreviewHtml(currentCode)
    }
  })

  const formatBtn = header.querySelector('[data-action="format"]')
  const copyBtn = header.querySelector('[data-action="copy"]')

  formatBtn.addEventListener('click', () => {
    if (!codeMirrorView) return
    const raw = codeMirrorView.state.doc.toString()
    const formatted = formatHtmlCode(raw)
    codeMirrorView.dispatch({
      changes: { from: 0, to: codeMirrorView.state.doc.length, insert: formatted }
    })
    syncToTextarea()
    ElMessage.success('代码已格式化')
  })

  copyBtn.addEventListener('click', () => {
    const code = codeMirrorView ? codeMirrorView.state.doc.toString() : sourceCode.value
    navigator.clipboard.writeText(code).then(() => {
      ElMessage.success('源码已复制到剪贴板')
    }).catch(() => {
      ElMessage.error('复制失败')
    })
  })

  return header
}

function createFooter(sourceEditingArea, textarea) {
  const footer = document.createElement('div')
  footer.className = 'source-panel-footer'
  footer.innerHTML = `
    <span class="source-hint">修改后点击"应用修改"同步到编辑器，或点击"取消"放弃修改</span>
    <div class="source-footer-actions">
      <button class="source-btn source-btn-cancel">取消</button>
      <button class="source-btn source-btn-apply">
        <svg viewBox="0 0 20 20" fill="currentColor" width="14" height="14"><path d="M17.28 5.22a.75.75 0 0 1 0 1.06l-9 9a.75.75 0 0 1-1.06 0l-4.5-4.5a.75.75 0 1 1 1.06-1.06L7.5 13.44l8.72-8.72a.75.75 0 0 1 1.06 0Z"/></svg>
        应用修改
      </button>
    </div>
  `

  const cancelBtn = footer.querySelector('.source-btn-cancel')
  const applyBtn = footer.querySelector('.source-btn-apply')

  cancelBtn.addEventListener('click', () => {
    const sourceEditingPlugin = editorInstance.value.plugins.get('SourceEditing')
    if (sourceEditingPlugin) {
      sourceCode.value = originalSourceCode.value
      textarea.value = originalSourceCode.value
      sourceEditingArea.dataset.value = originalSourceCode.value
      sourceEditingPlugin.isSourceEditingMode = false
    }
  })

  applyBtn.addEventListener('click', () => {
    syncToTextarea()
    const sourceEditingPlugin = editorInstance.value.plugins.get('SourceEditing')
    if (sourceEditingPlugin) {
      sourceEditingPlugin.isSourceEditingMode = false
    }
    ElMessage.success('HTML 源码已应用到编辑器')
  })

  return footer
}

function createCodeMirrorInstance(container, textarea, sourceEditingArea) {
  const updateListener = EditorView.updateListener.of((update) => {
    if (update.docChanged) {
      const value = update.state.doc.toString()
      textarea.value = value
      sourceEditingArea.dataset.value = value
      editorInstance.value.ui.update()

      sourceCode.value = value
      sourceModified.value = value !== originalSourceCode.value

      const cmHost = sourceEditingArea.querySelector('.cm-host-container')
      if (cmHost) {
        const status = cmHost.querySelector('.source-status')
        if (status) {
          status.textContent = sourceModified.value ? '已修改' : '未修改'
          status.className = 'source-status' + (sourceModified.value ? ' modified' : '')
        }
      }
    }
  })

  const state = EditorState.create({
    doc: textarea.value,
    extensions: [
      lineNumbers(),
      highlightActiveLineGutter(),
      highlightSpecialChars(),
      history(),
      foldGutter(),
      drawSelection(),
      indentOnInput(),
      bracketMatching(),
      closeBrackets(),
      autocompletion(),
      rectangularSelection(),
      highlightActiveLine(),
      highlightSelectionMatches(),
      syntaxHighlighting(defaultHighlightStyle, { fallback: true }),
      html(),
      oneDark,
      keymap.of([
        ...closeBracketsKeymap,
        ...defaultKeymap,
        ...searchKeymap,
        ...historyKeymap,
        ...foldKeymap,
        ...completionKeymap,
        indentWithTab
      ]),
      updateListener,
      EditorView.lineWrapping,
      EditorView.theme({
        '&': {
          height: '100%',
          fontSize: '13px'
        },
        '.cm-scroller': {
          overflow: 'auto',
          fontFamily: "'Consolas', 'Monaco', 'Courier New', monospace"
        },
        '.cm-gutters': {
          minHeight: '100%'
        }
      })
    ]
  })

  codeMirrorView = new EditorView({
    state,
    parent: container
  })

  codeMirrorView.focus()
}

function syncToTextarea() {
  if (!codeMirrorView) return
  const value = codeMirrorView.state.doc.toString()
  const editor = editorInstance.value
  if (!editor) return

  const editingView = editor.editing.view
  const domRoots = editingView.domRoots

  for (const [rootName, domRootElement] of domRoots) {
    const sourceEditingArea = domRootElement.parentElement
    if (!sourceEditingArea || !sourceEditingArea.classList.contains('ck-source-editing-area')) continue

    const textarea = sourceEditingArea.querySelector('textarea')
    if (textarea) {
      textarea.value = value
      sourceEditingArea.dataset.value = value
    }
  }
}

function destroyCodeMirror() {
  if (codeMirrorView) {
    codeMirrorView.destroy()
    codeMirrorView = null
  }

  const editor = editorInstance.value
  if (!editor) return

  const editingView = editor.editing.view
  const domRoots = editingView.domRoots

  for (const [rootName, domRootElement] of domRoots) {
    const sourceEditingArea = domRootElement.parentElement
    if (!sourceEditingArea || !sourceEditingArea.classList.contains('ck-source-editing-area')) continue

    const cmHost = sourceEditingArea.querySelector('.cm-host-container')
    if (cmHost) cmHost.remove()

    const textarea = sourceEditingArea.querySelector('textarea')
    if (textarea) textarea.style.display = ''
  }
}

function formatHtmlCode(raw) {
  let formatted = raw.replace(/></g, '>\n<')
  formatted = formatted.replace(/^\s+/gm, '')
  let indent = 0
  const lines = formatted.split('\n')
  const result = []
  const selfClosing = /^<(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)/i
  const closingTag = /^<\//i
  const openingTag = /^<[a-zA-Z]/i

  for (const line of lines) {
    const trimmed = line.trim()
    if (!trimmed) continue
    if (closingTag.test(trimmed)) indent = Math.max(0, indent - 1)
    result.push('  '.repeat(indent) + trimmed)
    if (openingTag.test(trimmed) && !selfClosing.test(trimmed) && !closingTag.test(trimmed) && !trimmed.includes('</')) indent++
  }
  return result.join('\n')
}

function getPreviewHtml(htmlContent) {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif; padding: 20px; line-height: 1.6; color: #333; }
    table { border-collapse: collapse; width: 100%; }
    th, td { border: 1px solid #ddd; padding: 8px 12px; text-align: left; }
    th { background: #f5f7fa; }
    img { max-width: 100%; }
    blockquote { border-left: 4px solid #ddd; margin: 0; padding-left: 16px; color: #666; }
    code { background: #f0f0f0; padding: 2px 6px; border-radius: 3px; font-size: 0.9em; }
  </style>
</head>
<body>${htmlContent}</body>
</html>`
}

function switchToPreview() {
  sourceTab.value = 'preview'
}

function cancelSourceEdit() {
  const sourceEditingPlugin = editorInstance.value?.plugins.get('SourceEditing')
  if (sourceEditingPlugin) {
    sourceEditingPlugin.isSourceEditingMode = false
  }
}

function applySourceCode() {
  syncToTextarea()
  const sourceEditingPlugin = editorInstance.value?.plugins.get('SourceEditing')
  if (sourceEditingPlugin) {
    sourceEditingPlugin.isSourceEditingMode = false
  }
  ElMessage.success('HTML 源码已应用到编辑器')
}

function openPreviewDialog() {
  previewDialogVisible.value = true
  nextTick(() => {
    const iframe = previewIframe.value
    if (iframe) {
      const htmlContent = editorInstance.value ? editorInstance.value.getData() : editorData.value
      iframe.srcdoc = getPreviewHtml(htmlContent)
    }
  })
}

function saveToDatabase() {
  saveForm.value = { name: '', description: '' }
  saveDialogVisible.value = true
}

function confirmSave() {
  if (!saveForm.value.name) {
    ElMessage.warning('请输入内容名称')
    return
  }
  const htmlContent = editorInstance.value ? editorInstance.value.getData() : editorData.value
  const saveData = {
    name: saveForm.value.name,
    description: saveForm.value.description,
    htmlContent,
    savedAt: new Date().toISOString()
  }
  localStorage.setItem('ckeditor5_html_content', JSON.stringify(saveData))
  saveDialogVisible.value = false
  ElMessage.success('内容已保存到本地存储（模拟数据库）')
}

function onTemplateInsert(html) {
  if (!editorInstance.value) return
  editorInstance.value.model.change(writer => {
    const viewFragment = editorInstance.value.data.processor.toView(html)
    const modelFragment = editorInstance.value.data.toModel(viewFragment)
    const insertPosition = editorInstance.value.model.document.selection.getFirstPosition()
    writer.insert(modelFragment, insertPosition)
  })
  editorInstance.value.editing.view.focus()
}

function onEditTemplate(template) {
  editingTemplate.value = template
  creatorVisible.value = true
}

function onTemplateSaved() {
  editingTemplate.value = null
  const panel = document.querySelector('.template-panel')
  if (panel && panel.__vueParentComponent) {
    panel.__vueParentComponent.exposed?.refreshTemplates?.()
  }
}

onBeforeUnmount(() => {
  destroyCodeMirror()
})
</script>

<style>
.source-panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  background: #181825;
  border-bottom: 1px solid #313244;
  height: 40px;
  flex-shrink: 0;
}

.source-panel-tabs {
  display: flex;
  gap: 0;
}

.source-tab {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 8px 14px;
  background: transparent;
  border: none;
  color: #a6adc8;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  transition: all 0.2s;
}

.source-tab:hover {
  color: #cdd6f4;
  background: rgba(255, 255, 255, 0.05);
}

.source-tab.active {
  color: #89b4fa;
  border-bottom-color: #89b4fa;
  background: rgba(137, 180, 250, 0.08);
}

.source-panel-actions {
  display: flex;
  align-items: center;
  gap: 6px;
}

.source-action-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid #313244;
  border-radius: 4px;
  color: #a6adc8;
  font-size: 11px;
  cursor: pointer;
  transition: all 0.15s;
}

.source-action-btn:hover {
  background: rgba(255, 255, 255, 0.1);
  color: #cdd6f4;
  border-color: #45475a;
}

.source-status {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 3px;
  background: rgba(166, 173, 200, 0.1);
  color: #a6adc8;
}

.source-status.modified {
  background: rgba(243, 139, 168, 0.15);
  color: #f38ba8;
}

.source-panel-footer {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 6px 12px;
  background: #181825;
  border-top: 1px solid #313244;
  height: 44px;
  z-index: 2;
}

.source-hint {
  font-size: 11px;
  color: #6c7086;
}

.source-footer-actions {
  display: flex;
  gap: 6px;
}

.source-btn {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 5px 14px;
  border: 1px solid #313244;
  border-radius: 4px;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s;
}

.source-btn-cancel {
  background: transparent;
  color: #a6adc8;
}

.source-btn-cancel:hover {
  background: rgba(255, 255, 255, 0.06);
  color: #cdd6f4;
}

.source-btn-apply {
  background: #89b4fa;
  color: #1e1e2e;
  border-color: #89b4fa;
  font-weight: 600;
}

.source-btn-apply:hover {
  background: #74c7ec;
  border-color: #74c7ec;
}

.cm-host-container .cm-editor {
  height: 100%;
}

.cm-host-container .cm-editor .cm-scroller {
  overflow: auto;
}

.cm-host-container .cm-editor.cm-focused {
  outline: none;
}

.preview-container .inline-preview-iframe {
  width: 100%;
  height: 100%;
  border: none;
}
</style>

<style scoped>
.html-editor-wrapper {
  max-width: 1400px;
  margin: 0 auto;
  padding: 20px;
  position: relative;
}

.editor-main {
  display: flex;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  overflow: hidden;
}

.editor-container {
  flex: 1;
  min-width: 0;
  overflow: hidden;
}

.template-toggle-btn {
  position: fixed;
  right: 20px;
  bottom: 80px;
  width: 40px;
  height: 40px;
  border-radius: 50%;
  background: #409eff;
  color: #fff;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 2px 12px rgba(64, 158, 255, 0.4);
  transition: all 0.3s;
  z-index: 100;
}

.template-toggle-btn:hover {
  transform: scale(1.1);
  box-shadow: 0 4px 16px rgba(64, 158, 255, 0.5);
}

.template-toggle-btn.active {
  background: #67c23a;
  box-shadow: 0 2px 12px rgba(103, 194, 58, 0.4);
}

.editor-container :deep(.ck.ck-editor) {
  border: none;
}

.editor-container :deep(.ck.ck-editor__top .ck-sticky-panel .ck-toolbar) {
  background: #fafafa;
  border-bottom: 1px solid #e0e0e0;
}

.editor-container :deep(.ck.ck-editor__main > .ck-editor__editable) {
  min-height: 400px;
  max-height: 600px;
  padding: 20px;
}

.editor-container :deep(.ck-source-editing-area) {
  background: #1e1e2e;
  min-height: 400px;
}

.editor-container :deep(.ck-source-editing-area textarea) {
  background: #1e1e2e;
  color: #cdd6f4;
  font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
}

.preview-container {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  overflow: hidden;
  background: #fff;
}

.preview-iframe {
  width: 100%;
  height: 65vh;
  border: none;
}
</style>
