<template>
  <el-dialog
    v-model="dialogVisible"
    title="图片编辑器"
    width="960px"
    top="3vh"
    :close-on-click-modal="false"
    destroy-on-close
    @opened="onDialogOpened"
    @close="onDialogClose"
  >
    <div class="image-editor">
      <div class="editor-workspace">
        <div class="editor-canvas" ref="canvasContainer">
          <img ref="editorImage" :src="imageSrc" crossorigin="anonymous" style="max-width: 100%; display: block;" />
        </div>
      </div>

      <div class="editor-sidebar">
        <div class="sidebar-section">
          <div class="section-title">裁剪形状</div>
          <div class="shape-grid">
            <button
              class="shape-btn"
              :class="{ active: cropShape === 'rect' }"
              @click="setCropShape('rect')"
            >
              <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><rect x="2" y="3" width="16" height="14" rx="1" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
              <span>方形</span>
            </button>
            <button
              class="shape-btn"
              :class="{ active: cropShape === 'circle' }"
              @click="setCropShape('circle')"
            >
              <svg viewBox="0 0 20 20" fill="currentColor" width="16" height="16"><circle cx="10" cy="10" r="8" stroke="currentColor" stroke-width="1.5" fill="none"/></svg>
              <span>圆形</span>
            </button>
          </div>
        </div>

        <div class="sidebar-section">
          <div class="section-title">裁剪比例</div>
          <div class="ratio-grid">
            <button
              v-for="item in aspectRatios"
              :key="item.label"
              class="ratio-btn"
              :class="{ active: currentRatio === item.value }"
              @click="setAspectRatio(item.value)"
            >
              {{ item.label }}
            </button>
          </div>
        </div>

        <div class="sidebar-section">
          <div class="section-title">旋转翻转</div>
          <div class="action-grid">
            <button class="action-btn" @click="rotateLeft" title="左旋转90°">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M7.11 8.53L5.7 7.11C4.8 8.27 4.24 9.61 4.07 11h2.02c.14-.87.49-1.72 1.02-2.47zM6.09 13H4.07c.17 1.39.72 2.73 1.62 3.89l1.41-1.42c-.52-.75-.87-1.59-1.01-2.47zm1.01 5.32c1.16.9 2.51 1.44 3.9 1.61V17.9c-.87-.15-1.71-.49-2.46-1.03L7.1 18.32zM13 4.07V1L8.45 5.55 13 10V6.09c2.84.48 5 2.94 5 5.91s-2.16 5.43-5 5.91v2.02c3.95-.49 7-3.85 7-7.93s-3.05-7.44-7-7.93z"/></svg>
              <span>左转</span>
            </button>
            <button class="action-btn" @click="rotateRight" title="右旋转90°">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M16.89 15.5l1.42 1.41c.9-1.16 1.45-2.5 1.62-3.91h-2.02c-.14.87-.48 1.72-1.02 2.5zm1.02-5.5h2.02c-.17-1.39-.72-2.73-1.62-3.89L15.9 7.52c.53.76.87 1.59 1.01 2.48zM13 6.09V1l4.55 4.55L13 10V6.09c-2.84.48-5 2.94-5 5.91s2.16 5.43 5 5.91v2.02c-3.95-.49-7-3.85-7-7.93s3.05-7.44 7-7.93z"/></svg>
              <span>右转</span>
            </button>
            <button class="action-btn" @click="flipHorizontal" title="水平翻转">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M15 21h2v-2h-2v2zm4-12h2V7h-2v2zM3 5v14c0 1.1.9 2 2 2h4v-2H5V5h4V3H5c-1.1 0-2 .9-2 2zm16-2v2h2c0-1.1-.9-2-2-2zm-8 20h2V1h-2v22zm8-6h2v-2h-2v2zM15 5h2V3h-2v2zm4 8h2v-2h-2v2zm0 8c1.1 0 2-.9 2-2h-2v2z"/></svg>
              <span>水平</span>
            </button>
            <button class="action-btn" @click="flipVertical" title="垂直翻转">
              <svg viewBox="0 0 24 24" fill="currentColor" width="18" height="18"><path d="M3 5h2V3H3v2zm0 8h2v-2H3v2zm4 8h2v-2H7v2zM3 9h2V7H3v2zm0 8h2v-2H3v2zm0 4h2v-2H3v2zm8-16h2V3h-2v2zm8 0h2V3h-2v2zm-8 8h2v-2h-2v2zm8 0h2v-2h-2v2zm0 8h2v-2h-2v2zm-8 0h2v-2h-2v2zm0-16h2V7h-2v2zm8 0h2V7h-2v2zm-8 8h2v-2h-2v2zM3 21h2v-2H3v2zm8-4h2v-2h-2v2zm4 4h2v-2h-2v2z"/></svg>
              <span>垂直</span>
            </button>
          </div>
        </div>

        <div class="sidebar-section">
          <div class="section-title">缩放</div>
          <div class="zoom-control">
            <el-button size="small" @click="zoomOut" :icon="ZoomOut" circle />
            <el-slider
              v-model="zoomPercent"
              :min="10"
              :max="300"
              :step="1"
              :format-tooltip="v => v + '%'"
              @input="onZoomChange"
              style="flex: 1; margin: 0 8px;"
            />
            <el-button size="small" @click="zoomIn" :icon="ZoomIn" circle />
          </div>
          <div class="zoom-value">{{ zoomPercent }}%</div>
        </div>

        <div class="sidebar-section">
          <div class="section-title">预览</div>
          <div class="preview-box" ref="previewBox">
            <img v-if="previewSrc" :src="previewSrc" class="preview-img" />
            <span v-else class="preview-empty">裁剪后预览</span>
          </div>
        </div>
      </div>
    </div>

    <template #footer>
      <div class="dialog-footer">
        <el-button @click="resetEditor">重置</el-button>
        <el-button @click="dialogVisible = false">取消</el-button>
        <el-button type="primary" @click="saveImage" :loading="saving">保存</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, nextTick, onBeforeUnmount, watch } from 'vue'
import { ElMessage } from 'element-plus'
import { ZoomIn, ZoomOut } from '@element-plus/icons-vue'
import Cropper from 'cropperjs'
import 'cropperjs/dist/cropper.css'

const props = defineProps({
  modelValue: { type: Boolean, default: false },
  src: { type: String, default: '' }
})

const emit = defineEmits(['update:modelValue', 'save'])

const dialogVisible = computed({
  get() { return props.modelValue },
  set(v) { emit('update:modelValue', v) }
})

const imageSrc = ref('')
const editorImage = ref(null)
const canvasContainer = ref(null)
const previewBox = ref(null)
const previewSrc = ref('')
const zoomPercent = ref(100)
const currentRatio = ref(NaN)
const cropShape = ref('rect')
const saving = ref(false)

let cropper = null

const aspectRatios = [
  { label: '自由', value: NaN },
  { label: '1:1', value: 1 },
  { label: '4:3', value: 4 / 3 },
  { label: '3:4', value: 3 / 4 },
  { label: '16:9', value: 16 / 9 },
  { label: '9:16', value: 9 / 16 },
  { label: '3:2', value: 3 / 2 },
  { label: '2:3', value: 2 / 3 }
]

watch(() => props.modelValue, (val) => {
  if (val) {
    imageSrc.value = props.src
    dialogVisible.value = true
  }
})

watch(() => props.src, (val) => {
  if (val && dialogVisible.value) {
    imageSrc.value = val
    nextTick(() => initCropper())
  }
})

function onDialogOpened() {
  nextTick(() => initCropper())
}

function onDialogClose() {
  destroyCropper()
}

function initCropper() {
  destroyCropper()
  if (!editorImage.value) return

  cropper = new Cropper(editorImage.value, {
    viewMode: 1,
    dragMode: 'move',
    aspectRatio: currentRatio.value,
    autoCropArea: 1,
    restore: false,
    guides: true,
    center: true,
    highlight: true,
    cropBoxMovable: true,
    cropBoxResizable: true,
    toggleDragModeOnDblclick: false,
    ready() {
      updatePreview()
      updateZoom()
    },
    crop() {
      updatePreview()
    },
    zoom() {
      updateZoom()
    }
  })
}

function destroyCropper() {
  if (cropper) {
    cropper.destroy()
    cropper = null
  }
}

function updatePreview() {
  if (!cropper) return
  try {
    const canvas = cropper.getCroppedCanvas({ maxWidth: 256, maxHeight: 256 })
    if (canvas) {
      previewSrc.value = canvas.toDataURL('image/png')
    }
  } catch (e) {
    // ignore
  }
}

function updateZoom() {
  if (!cropper) return
  try {
    const data = cropper.getCanvasData()
    const containerData = cropper.getContainerData()
    if (data && containerData && data.naturalWidth) {
      zoomPercent.value = Math.round((data.width / data.naturalWidth) * 100)
    }
  } catch (e) {
    // ignore
  }
}

function setAspectRatio(ratio) {
  currentRatio.value = ratio
  if (cropper) {
    cropper.setAspectRatio(ratio)
  }
}

function setCropShape(shape) {
  cropShape.value = shape
  const canvasEl = canvasContainer.value
  if (!canvasEl) return

  if (shape === 'circle') {
    canvasEl.classList.add('circle-crop')
    if (cropper) cropper.setAspectRatio(1)
    currentRatio.value = 1
  } else {
    canvasEl.classList.remove('circle-crop')
  }
}

function rotateLeft() {
  if (cropper) cropper.rotate(-90)
}

function rotateRight() {
  if (cropper) cropper.rotate(90)
}

function flipHorizontal() {
  if (!cropper) return
  const data = cropper.getData()
  cropper.scaleX(data.scaleX === 1 ? -1 : 1)
}

function flipVertical() {
  if (!cropper) return
  const data = cropper.getData()
  cropper.scaleY(data.scaleY === 1 ? -1 : 1)
}

function zoomIn() {
  if (cropper) cropper.zoom(0.1)
}

function zoomOut() {
  if (cropper) cropper.zoom(-0.1)
}

function onZoomChange(val) {
  if (!cropper) return
  const data = cropper.getCanvasData()
  if (data && data.naturalWidth) {
    const newWidth = data.naturalWidth * (val / 100)
    cropper.zoomTo(newWidth / data.width)
  }
}

function resetEditor() {
  if (cropper) {
    cropper.reset()
    currentRatio.value = NaN
    zoomPercent.value = 100
    cropShape.value = 'rect'
    const canvasEl = canvasContainer.value
    if (canvasEl) canvasEl.classList.remove('circle-crop')
  }
}

async function saveImage() {
  if (!cropper) {
    ElMessage.warning('请先加载图片')
    return
  }

  saving.value = true
  try {
    const canvas = cropper.getCroppedCanvas({
      maxWidth: 4096,
      maxHeight: 4096,
      imageSmoothingEnabled: true,
      imageSmoothingQuality: 'high'
    })

    if (!canvas) {
      ElMessage.error('裁剪失败，请重试')
      return
    }

    let finalCanvas = canvas

    if (cropShape.value === 'circle') {
      const size = Math.min(canvas.width, canvas.height)
      finalCanvas = document.createElement('canvas')
      finalCanvas.width = size
      finalCanvas.height = size
      const ctx = finalCanvas.getContext('2d')
      ctx.beginPath()
      ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2)
      ctx.closePath()
      ctx.clip()
      const sx = (canvas.width - size) / 2
      const sy = (canvas.height - size) / 2
      ctx.drawImage(canvas, sx, sy, size, size, 0, 0, size, size)
    }

    const blob = await new Promise(resolve => finalCanvas.toBlob(resolve, 'image/png', 0.95))

    const result = {
      blob,
      url: URL.createObjectURL(blob),
      width: canvas.width,
      height: canvas.height
    }

    emit('save', result)

    console.log('模拟保存图片:', {
      width: result.width,
      height: result.height,
      size: (result.blob.size / 1024).toFixed(1) + 'KB'
    })

    ElMessage.success('图片已保存')
    dialogVisible.value = false
  } catch (e) {
    ElMessage.error('保存失败: ' + e.message)
  } finally {
    saving.value = false
  }
}

onBeforeUnmount(() => {
  destroyCropper()
})

function open(src) {
  imageSrc.value = src
  emit('update:modelValue', true)
}

defineExpose({ open })
</script>

<style scoped>
.image-editor {
  display: flex;
  gap: 16px;
  height: 520px;
}

.editor-workspace {
  flex: 1;
  min-width: 0;
  background: #1a1a1a;
  border-radius: 6px;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.editor-canvas {
  width: 100%;
  height: 100%;
}

.editor-canvas :deep(.cropper-container) {
  width: 100% !important;
  height: 100% !important;
}

.editor-canvas img {
  display: block;
  max-width: 100%;
}

.editor-canvas.circle-crop :deep(.cropper-view-box) {
  border-radius: 50%;
}

.editor-canvas.circle-crop :deep(.cropper-face) {
  border-radius: 50%;
}

.editor-canvas.circle-crop :deep(.cropper-dashed) {
  border-radius: 50%;
}

.editor-sidebar {
  width: 240px;
  flex-shrink: 0;
  display: flex;
  flex-direction: column;
  gap: 12px;
  overflow-y: auto;
}

.sidebar-section {
  background: #f9fafb;
  border-radius: 6px;
  padding: 10px 12px;
}

.section-title {
  font-size: 12px;
  font-weight: 600;
  color: #606266;
  margin-bottom: 8px;
}

.shape-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 4px;
}

.shape-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 6px 0;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background: #fff;
  color: #606266;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.15s;
}

.shape-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

.shape-btn.active {
  background: #409eff;
  border-color: #409eff;
  color: #fff;
}

.shape-btn span {
  font-size: 11px;
}

.ratio-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 4px;
}

.ratio-btn {
  padding: 5px 0;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background: #fff;
  color: #606266;
  font-size: 11px;
  cursor: pointer;
  transition: all 0.15s;
}

.ratio-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

.ratio-btn.active {
  background: #409eff;
  border-color: #409eff;
  color: #fff;
}

.action-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 4px;
}

.action-btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  padding: 6px 0;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  background: #fff;
  color: #606266;
  cursor: pointer;
  transition: all 0.15s;
}

.action-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

.action-btn span {
  font-size: 10px;
}

.zoom-control {
  display: flex;
  align-items: center;
  gap: 4px;
}

.zoom-value {
  text-align: center;
  font-size: 12px;
  color: #909399;
  margin-top: 4px;
}

.preview-box {
  width: 100%;
  height: 140px;
  background: #f0f0f0;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.preview-img {
  max-width: 100%;
  max-height: 100%;
  object-fit: contain;
}

.preview-empty {
  font-size: 12px;
  color: #c0c4cc;
}

.dialog-footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
</style>
