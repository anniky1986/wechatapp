<template>
  <transition name="panel-slide">
    <div v-if="visible" class="template-panel">
      <div class="panel-header">
        <h3>内容模板</h3>
        <el-button text size="small" @click="$emit('close')" :icon="Close" />
      </div>

      <div class="panel-search">
        <el-input
          v-model="searchQuery"
          placeholder="搜索模板..."
          prefix-icon="Search"
          clearable
          size="small"
        />
      </div>

      <div class="panel-categories">
        <button
          v-for="cat in categories"
          :key="cat.key"
          class="category-btn"
          :class="{ active: activeCategory === cat.key }"
          @click="activeCategory = cat.key"
        >
          <span class="cat-icon">{{ cat.icon }}</span>
          <span class="cat-label">{{ cat.label }}</span>
        </button>
      </div>

      <div class="panel-templates">
        <div class="templates-grid">
          <div
            v-for="tpl in filteredTemplates"
            :key="tpl.id"
            class="template-item"
            @click="onTemplateClick(tpl)"
          >
            <div class="template-preview" v-html="getPreviewHtml(tpl)"></div>
            <div class="template-name">{{ tpl.name }}</div>
            <div class="template-actions">
              <el-button
                v-if="tpl.source === 'custom'"
                text
                size="small"
                @click.stop="$emit('edit', tpl)"
              >
                <el-icon><Edit /></el-icon>
              </el-button>
              <el-button
                v-if="tpl.source === 'custom'"
                text
                size="small"
                type="danger"
                @click.stop="onDelete(tpl)"
              >
                <el-icon><Delete /></el-icon>
              </el-button>
            </div>
          </div>
        </div>

        <div v-if="filteredTemplates.length === 0" class="empty-state">
          <p>暂无模板</p>
          <el-button type="primary" size="small" @click="$emit('create')">
            创建模板
          </el-button>
        </div>
      </div>

      <div class="panel-footer">
        <el-button type="primary" size="small" @click="$emit('create')" style="width: 100%;">
          + 创建新模板
        </el-button>
      </div>

      <el-dialog
        v-model="fillDialogVisible"
        title="填写模板内容"
        width="480px"
        append-to-body
        destroy-on-close
      >
        <el-form label-width="80px" v-if="selectedTemplate">
          <el-form-item
            v-for="(zone, index) in editableZones"
            :key="index"
            :label="zone.placeholder"
          >
            <el-input
              v-model="fillData[zone.placeholder]"
              :placeholder="'请输入' + zone.placeholder"
              :type="zone.type === 'textarea' ? 'textarea' : 'text'"
              :rows="3"
            />
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="fillDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="insertWithFill">插入模板</el-button>
        </template>
      </el-dialog>
    </div>
  </transition>
</template>

<script setup>
import { ref, computed, watch } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { Close, Edit, Delete } from '@element-plus/icons-vue'
import { categories, getAllTemplates, deleteCustomTemplate } from '../templates/index.js'

const props = defineProps({
  visible: { type: Boolean, default: false }
})

const emit = defineEmits(['close', 'insert', 'create', 'edit'])

const searchQuery = ref('')
const activeCategory = ref('title')
const fillDialogVisible = ref(false)
const selectedTemplate = ref(null)
const fillData = ref({})

const allTemplates = ref(getAllTemplates())

const filteredTemplates = computed(() => {
  let list = allTemplates.value

  if (activeCategory.value === 'custom') {
    list = list.filter(t => t.source === 'custom')
  } else {
    list = list.filter(t => t.category === activeCategory.value && t.source !== 'custom')
  }

  if (searchQuery.value.trim()) {
    const q = searchQuery.value.trim().toLowerCase()
    list = list.filter(t =>
      t.name.toLowerCase().includes(q) ||
      (t.tags && t.tags.some(tag => tag.toLowerCase().includes(q)))
    )
  }

  return list
})

function getPreviewHtml(template) {
  let html = template.html
  html = html.replace(/\{\{(.+?)\}\}/g, '<span style="color:#409eff;font-style:italic;">[$1]</span>')
  const previewStyles = `
    <style>
      .preview-wrapper { font-size: 11px; line-height: 1.4; overflow: hidden; }
      .preview-wrapper img { max-width: 100%; }
      .preview-wrapper h2 { font-size: 14px; margin: 4px 0; }
      .preview-wrapper h3 { font-size: 13px; margin: 4px 0; }
      .preview-wrapper p { font-size: 11px; margin: 2px 0; }
      .preview-wrapper section { font-size: 11px; }
    </style>
  `
  return `<div class="preview-wrapper">${previewStyles}${html}</div>`
}

function extractEditableZones(html) {
  const zones = []
  const regex = /\{\{(.+?)\}\}/g
  let match
  while ((match = regex.exec(html)) !== null) {
    const placeholder = match[1]
    if (!zones.find(z => z.placeholder === placeholder)) {
      zones.push({
        placeholder,
        type: placeholder.includes('内容') || placeholder.includes('描述') ? 'textarea' : 'text'
      })
    }
  }
  return zones
}

const editableZones = computed(() => {
  if (!selectedTemplate.value) return []
  return extractEditableZones(selectedTemplate.value.html)
})

function onTemplateClick(template) {
  const zones = extractEditableZones(template.html)
  if (zones.length > 0) {
    selectedTemplate.value = template
    fillData.value = {}
    zones.forEach(z => {
      fillData.value[z.placeholder] = ''
    })
    fillDialogVisible.value = true
  } else {
    emit('insert', template.html)
  }
}

function insertWithFill() {
  if (!selectedTemplate.value) return
  let html = selectedTemplate.value.html
  for (const [key, value] of Object.entries(fillData.value)) {
    const replacement = value || key
    html = html.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), replacement)
  }
  emit('insert', html)
  fillDialogVisible.value = false
  ElMessage.success('模板已插入')
}

function onDelete(template) {
  ElMessageBox.confirm(`确定删除模板"${template.name}"吗？`, '提示', {
    confirmButtonText: '确定',
    cancelButtonText: '取消',
    type: 'warning'
  }).then(() => {
    const updated = deleteCustomTemplate(template.id)
    allTemplates.value = [...getAllTemplates()]
    ElMessage.success('模板已删除')
  }).catch(() => {})
}

function refreshTemplates() {
  allTemplates.value = getAllTemplates()
}

watch(() => props.visible, (val) => {
  if (val) refreshTemplates()
})

defineExpose({ refreshTemplates })
</script>

<style scoped>
.template-panel {
  width: 300px;
  min-width: 300px;
  background: #fff;
  border-left: 1px solid #e0e0e0;
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.panel-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 14px;
  border-bottom: 1px solid #f0f0f0;
  flex-shrink: 0;
}

.panel-header h3 {
  font-size: 15px;
  font-weight: 600;
  color: #303133;
  margin: 0;
}

.panel-search {
  padding: 8px 14px;
  flex-shrink: 0;
}

.panel-categories {
  display: flex;
  flex-wrap: wrap;
  gap: 4px;
  padding: 4px 14px 8px;
  flex-shrink: 0;
}

.category-btn {
  display: inline-flex;
  align-items: center;
  gap: 3px;
  padding: 4px 10px;
  border: 1px solid #e0e0e0;
  border-radius: 14px;
  background: #fff;
  color: #606266;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s;
}

.category-btn:hover {
  border-color: #409eff;
  color: #409eff;
}

.category-btn.active {
  background: #409eff;
  border-color: #409eff;
  color: #fff;
}

.cat-icon {
  font-size: 12px;
}

.cat-label {
  font-size: 11px;
}

.panel-templates {
  flex: 1;
  overflow-y: auto;
  padding: 8px 14px;
}

.templates-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 10px;
}

.template-item {
  border: 1px solid #ebeef5;
  border-radius: 6px;
  overflow: hidden;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.template-item:hover {
  border-color: #409eff;
  box-shadow: 0 2px 8px rgba(64, 158, 255, 0.15);
}

.template-item:hover .template-actions {
  opacity: 1;
}

.template-preview {
  padding: 8px;
  min-height: 60px;
  max-height: 100px;
  overflow: hidden;
  background: #fafafa;
  display: flex;
  align-items: center;
  justify-content: center;
}

.template-name {
  padding: 6px 8px;
  font-size: 11px;
  color: #606266;
  text-align: center;
  border-top: 1px solid #f0f0f0;
  background: #fff;
}

.template-actions {
  position: absolute;
  top: 4px;
  right: 4px;
  opacity: 0;
  transition: opacity 0.2s;
  display: flex;
  gap: 2px;
  background: rgba(255,255,255,0.9);
  border-radius: 4px;
  padding: 2px;
}

.empty-state {
  text-align: center;
  padding: 40px 20px;
  color: #909399;
}

.empty-state p {
  margin-bottom: 12px;
  font-size: 13px;
}

.panel-footer {
  padding: 10px 14px;
  border-top: 1px solid #f0f0f0;
  flex-shrink: 0;
}

.panel-slide-enter-active,
.panel-slide-leave-active {
  transition: all 0.3s ease;
}

.panel-slide-enter-from,
.panel-slide-leave-to {
  width: 0;
  min-width: 0;
  opacity: 0;
}
</style>
