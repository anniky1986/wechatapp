<script setup>
import { ref } from 'vue'
import HtmlEditor from './components/HtmlEditor.vue'
import ImageEditor from './components/ImageEditor.vue'

const imageEditorVisible = ref(false)
const imageEditorSrc = ref('')

function openImageEditor() {
  imageEditorSrc.value = 'https://via.placeholder.com/800x600/409eff/ffffff?text=Demo+Image'
  imageEditorVisible.value = true
}

function onImageSave(result) {
  console.log('图片保存结果:', result)
}
</script>

<template>
  <div class="app-container">
    <header class="app-header">
      <h1>CKEditor5 HTML 编辑器</h1>
      <p class="subtitle">基于开源版本 + GeneralHtmlSupport + SourceEditing 插件</p>
      <div class="header-actions">
        <el-button size="small" @click="openImageEditor">图片编辑器</el-button>
      </div>
    </header>
    <HtmlEditor />
    <ImageEditor
      v-model="imageEditorVisible"
      :src="imageEditorSrc"
      @save="onImageSave"
    />
  </div>
</template>

<style scoped>
.app-container {
  min-height: 100vh;
  background: #f5f7fa;
}

.app-header {
  text-align: center;
  padding: 24px 20px 8px;
}

.app-header h1 {
  font-size: 24px;
  color: #303133;
  margin-bottom: 4px;
}

.subtitle {
  color: #909399;
  font-size: 14px;
  margin-bottom: 8px;
}

.header-actions {
  margin-top: 8px;
}
</style>
