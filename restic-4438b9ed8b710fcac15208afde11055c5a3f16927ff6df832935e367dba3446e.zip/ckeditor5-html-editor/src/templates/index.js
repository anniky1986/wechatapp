export const categories = [
  { key: 'title', label: '标题样式', icon: '📝' },
  { key: 'card', label: '内容卡片', icon: '🃏' },
  { key: 'divider', label: '分割线', icon: '✂️' },
  { key: 'image-text', label: '图文排版', icon: '🖼️' },
  { key: 'quote', label: '引用框', icon: '💬' },
  { key: 'custom', label: '我的模板', icon: '⭐' }
]

export const builtInTemplates = [
  {
    id: 'title-gradient-01',
    name: '渐变标题',
    category: 'title',
    tags: ['标题', '渐变'],
    html: `<section style="margin: 20px 0; text-align: center;">
  <h2 style="display: inline-block; padding: 8px 24px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #ffffff; font-size: 22px; font-weight: bold; border-radius: 4px; margin: 0;">{{标题文字}}</h2>
</section>`
  },
  {
    id: 'title-underline-01',
    name: '下划线标题',
    category: 'title',
    tags: ['标题', '下划线'],
    html: `<section style="margin: 20px 0;">
  <h2 style="font-size: 20px; font-weight: bold; color: #333333; padding-bottom: 8px; border-bottom: 3px solid #409eff; margin: 0;">{{标题文字}}</h2>
</section>`
  },
  {
    id: 'title-left-bar-01',
    name: '左侧竖条标题',
    category: 'title',
    tags: ['标题', '竖条'],
    html: `<section style="margin: 20px 0; display: flex; align-items: center;">
  <section style="width: 4px; height: 24px; background: #409eff; border-radius: 2px; margin-right: 10px; flex-shrink: 0;"></section>
  <h2 style="font-size: 18px; font-weight: bold; color: #333333; margin: 0;">{{标题文字}}</h2>
</section>`
  },
  {
    id: 'title-bg-01',
    name: '背景色标题',
    category: 'title',
    tags: ['标题', '背景'],
    html: `<section style="margin: 20px 0; background: #ecf5ff; border-radius: 6px; padding: 12px 16px;">
  <h2 style="font-size: 18px; font-weight: bold; color: #409eff; margin: 0;">{{标题文字}}</h2>
</section>`
  },
  {
    id: 'title-number-01',
    name: '编号标题',
    category: 'title',
    tags: ['标题', '编号'],
    html: `<section style="margin: 20px 0; display: flex; align-items: center;">
  <section style="width: 28px; height: 28px; background: #409eff; color: #ffffff; border-radius: 50%; text-align: center; line-height: 28px; font-size: 14px; font-weight: bold; margin-right: 10px; flex-shrink: 0;">1</section>
  <h2 style="font-size: 18px; font-weight: bold; color: #333333; margin: 0;">{{标题文字}}</h2>
</section>`
  },
  {
    id: 'card-simple-01',
    name: '简约卡片',
    category: 'card',
    tags: ['卡片', '简约'],
    html: `<section style="margin: 16px 0; padding: 16px; border: 1px solid #e0e0e0; border-radius: 8px; background: #ffffff;">
  <h3 style="font-size: 16px; font-weight: bold; color: #333333; margin: 0 0 8px 0;">{{卡片标题}}</h3>
  <p style="font-size: 14px; color: #666666; line-height: 1.8; margin: 0;">{{卡片内容}}</p>
</section>`
  },
  {
    id: 'card-shadow-01',
    name: '阴影卡片',
    category: 'card',
    tags: ['卡片', '阴影'],
    html: `<section style="margin: 16px 0; padding: 20px; border-radius: 8px; background: #ffffff; box-shadow: 0 2px 12px rgba(0,0,0,0.1);">
  <h3 style="font-size: 16px; font-weight: bold; color: #333333; margin: 0 0 8px 0;">{{卡片标题}}</h3>
  <p style="font-size: 14px; color: #666666; line-height: 1.8; margin: 0;">{{卡片内容}}</p>
</section>`
  },
  {
    id: 'card-gradient-01',
    name: '渐变卡片',
    category: 'card',
    tags: ['卡片', '渐变'],
    html: `<section style="margin: 16px 0; padding: 20px; border-radius: 8px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #ffffff;">
  <h3 style="font-size: 16px; font-weight: bold; color: #ffffff; margin: 0 0 8px 0;">{{卡片标题}}</h3>
  <p style="font-size: 14px; color: rgba(255,255,255,0.9); line-height: 1.8; margin: 0;">{{卡片内容}}</p>
</section>`
  },
  {
    id: 'card-top-border-01',
    name: '顶部色条卡片',
    category: 'card',
    tags: ['卡片', '色条'],
    html: `<section style="margin: 16px 0; border-radius: 8px; overflow: hidden;">
  <section style="height: 4px; background: linear-gradient(90deg, #409eff, #67c23a);"></section>
  <section style="padding: 16px; border: 1px solid #e0e0e0; border-top: none; border-radius: 0 0 8px 8px; background: #ffffff;">
    <h3 style="font-size: 16px; font-weight: bold; color: #333333; margin: 0 0 8px 0;">{{卡片标题}}</h3>
    <p style="font-size: 14px; color: #666666; line-height: 1.8; margin: 0;">{{卡片内容}}</p>
  </section>
</section>`
  },
  {
    id: 'card-left-accent-01',
    name: '左侧强调卡片',
    category: 'card',
    tags: ['卡片', '强调'],
    html: `<section style="margin: 16px 0; display: flex; border-radius: 8px; overflow: hidden;">
  <section style="width: 4px; background: #e6a23c; flex-shrink: 0;"></section>
  <section style="flex: 1; padding: 16px; background: #fdf6ec; border-radius: 0 8px 8px 0;">
    <h3 style="font-size: 16px; font-weight: bold; color: #333333; margin: 0 0 8px 0;">{{卡片标题}}</h3>
    <p style="font-size: 14px; color: #666666; line-height: 1.8; margin: 0;">{{卡片内容}}</p>
  </section>
</section>`
  },
  {
    id: 'divider-line-01',
    name: '简约分割线',
    category: 'divider',
    tags: ['分割线', '简约'],
    html: `<section style="margin: 20px 0; text-align: center;">
  <section style="display: inline-block; width: 60px; height: 2px; background: #dcdfe6;"></section>
</section>`
  },
  {
    id: 'divider-dot-01',
    name: '圆点分割线',
    category: 'divider',
    tags: ['分割线', '圆点'],
    html: `<section style="margin: 20px 0; text-align: center; letter-spacing: 6px; color: #409eff;">● ● ●</section>`
  },
  {
    id: 'divider-gradient-01',
    name: '渐变分割线',
    category: 'divider',
    tags: ['分割线', '渐变'],
    html: `<section style="margin: 20px 0;">
  <section style="height: 2px; background: linear-gradient(90deg, transparent, #409eff, transparent);"></section>
</section>`
  },
  {
    id: 'divider-icon-01',
    name: '图标分割线',
    category: 'divider',
    tags: ['分割线', '图标'],
    html: `<section style="margin: 20px 0; display: flex; align-items: center; justify-content: center;">
  <section style="flex: 1; height: 1px; background: #dcdfe6;"></section>
  <section style="padding: 0 12px; color: #409eff; font-size: 16px;">✦</section>
  <section style="flex: 1; height: 1px; background: #dcdfe6;"></section>
</section>`
  },
  {
    id: 'divider-wave-01',
    name: '波浪分割线',
    category: 'divider',
    tags: ['分割线', '波浪'],
    html: `<section style="margin: 20px 0; text-align: center; color: #67c23a; font-size: 20px; letter-spacing: 4px;">〰〰〰〰〰</section>`
  },
  {
    id: 'image-text-left-01',
    name: '左图右文',
    category: 'image-text',
    tags: ['图文', '左图右文'],
    html: `<section style="margin: 16px 0; display: flex; gap: 12px; align-items: flex-start;">
  <section style="flex-shrink: 0; width: 120px; height: 90px; background: #f5f7fa; border-radius: 6px; overflow: hidden;">
    <img src="https://via.placeholder.com/120x90/e0e0e0/999999?text=图片" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
  </section>
  <section style="flex: 1;">
    <h3 style="font-size: 15px; font-weight: bold; color: #333333; margin: 0 0 6px 0;">{{标题}}</h3>
    <p style="font-size: 13px; color: #999999; line-height: 1.6; margin: 0;">{{描述文字}}</p>
  </section>
</section>`
  },
  {
    id: 'image-text-right-01',
    name: '右图左文',
    category: 'image-text',
    tags: ['图文', '右图左文'],
    html: `<section style="margin: 16px 0; display: flex; gap: 12px; align-items: flex-start;">
  <section style="flex: 1;">
    <h3 style="font-size: 15px; font-weight: bold; color: #333333; margin: 0 0 6px 0;">{{标题}}</h3>
    <p style="font-size: 13px; color: #999999; line-height: 1.6; margin: 0;">{{描述文字}}</p>
  </section>
  <section style="flex-shrink: 0; width: 120px; height: 90px; background: #f5f7fa; border-radius: 6px; overflow: hidden;">
    <img src="https://via.placeholder.com/120x90/e0e0e0/999999?text=图片" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
  </section>
</section>`
  },
  {
    id: 'image-text-top-01',
    name: '上图下文',
    category: 'image-text',
    tags: ['图文', '上图下文'],
    html: `<section style="margin: 16px 0; border-radius: 8px; overflow: hidden; border: 1px solid #e0e0e0;">
  <section style="width: 100%; height: 160px; background: #f5f7fa; overflow: hidden;">
    <img src="https://via.placeholder.com/400x160/e0e0e0/999999?text=图片" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
  </section>
  <section style="padding: 12px 16px;">
    <h3 style="font-size: 16px; font-weight: bold; color: #333333; margin: 0 0 6px 0;">{{标题}}</h3>
    <p style="font-size: 13px; color: #999999; line-height: 1.6; margin: 0;">{{描述文字}}</p>
  </section>
</section>`
  },
  {
    id: 'image-text-grid-01',
    name: '双列图文',
    category: 'image-text',
    tags: ['图文', '双列'],
    html: `<section style="margin: 16px 0; display: flex; gap: 12px;">
  <section style="flex: 1; border-radius: 6px; overflow: hidden; border: 1px solid #e0e0e0;">
    <section style="width: 100%; height: 100px; background: #f5f7fa; overflow: hidden;">
      <img src="https://via.placeholder.com/200x100/e0e0e0/999999?text=图片1" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
    </section>
    <section style="padding: 8px 10px;">
      <p style="font-size: 13px; color: #333333; font-weight: bold; margin: 0;">{{标题1}}</p>
    </section>
  </section>
  <section style="flex: 1; border-radius: 6px; overflow: hidden; border: 1px solid #e0e0e0;">
    <section style="width: 100%; height: 100px; background: #f5f7fa; overflow: hidden;">
      <img src="https://via.placeholder.com/200x100/e0e0e0/999999?text=图片2" style="width: 100%; height: 100%; object-fit: cover; display: block;" />
    </section>
    <section style="padding: 8px 10px;">
      <p style="font-size: 13px; color: #333333; font-weight: bold; margin: 0;">{{标题2}}</p>
    </section>
  </section>
</section>`
  },
  {
    id: 'quote-simple-01',
    name: '简约引用',
    category: 'quote',
    tags: ['引用', '简约'],
    html: `<section style="margin: 16px 0; padding: 12px 16px; border-left: 4px solid #409eff; background: #ecf5ff; border-radius: 0 6px 6px 0;">
  <p style="font-size: 14px; color: #409eff; line-height: 1.8; margin: 0; font-style: italic;">{{引用内容}}</p>
</section>`
  },
  {
    id: 'quote-double-01',
    name: '双引号引用',
    category: 'quote',
    tags: ['引用', '双引号'],
    html: `<section style="margin: 16px 0; padding: 20px 24px; background: #fafafa; border-radius: 8px; position: relative;">
  <section style="font-size: 40px; color: #dcdfe6; line-height: 1; font-family: Georgia, serif; position: absolute; top: 8px; left: 12px;">"</section>
  <p style="font-size: 14px; color: #666666; line-height: 1.8; margin: 0; padding-top: 16px;">{{引用内容}}</p>
  <p style="font-size: 12px; color: #999999; margin: 8px 0 0 0; text-align: right;">—— {{署名}}</p>
</section>`
  },
  {
    id: 'quote-warning-01',
    name: '提示引用',
    category: 'quote',
    tags: ['引用', '提示'],
    html: `<section style="margin: 16px 0; padding: 12px 16px; border-left: 4px solid #e6a23c; background: #fdf6ec; border-radius: 0 6px 6px 0;">
  <p style="font-size: 14px; color: #e6a23c; line-height: 1.8; margin: 0;">💡 {{提示内容}}</p>
</section>`
  },
  {
    id: 'quote-success-01',
    name: '成功引用',
    category: 'quote',
    tags: ['引用', '成功'],
    html: `<section style="margin: 16px 0; padding: 12px 16px; border-left: 4px solid #67c23a; background: #f0f9eb; border-radius: 0 6px 6px 0;">
  <p style="font-size: 14px; color: #67c23a; line-height: 1.8; margin: 0;">✅ {{成功提示内容}}</p>
</section>`
  }
]

export function getCustomTemplates() {
  try {
    const data = localStorage.getItem('ckeditor5_custom_templates')
    return data ? JSON.parse(data) : []
  } catch {
    return []
  }
}

export function saveCustomTemplate(template) {
  const templates = getCustomTemplates()
  const existing = templates.findIndex(t => t.id === template.id)
  if (existing >= 0) {
    templates[existing] = template
  } else {
    templates.push(template)
  }
  localStorage.setItem('ckeditor5_custom_templates', JSON.stringify(templates))
  return templates
}

export function deleteCustomTemplate(id) {
  const templates = getCustomTemplates().filter(t => t.id !== id)
  localStorage.setItem('ckeditor5_custom_templates', JSON.stringify(templates))
  return templates
}

export function getAllTemplates() {
  return [...builtInTemplates, ...getCustomTemplates()]
}
